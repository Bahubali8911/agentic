# KYC Auditor

A four-agent AI pipeline that audits client KYC documents using Google ADK and Gemini.

## What it does

Given a `client_id`, the pipeline:
1. **Fetches** all documents on file for the client from the document API
2. **Classifies** each document (PASSPORT, BANK_STATEMENT, etc.) via DocAI
3. **Matches** the classified set against the KYC checklist for the client type
4. **Produces** a structured compliance report and uploads it to storage

## Project layout

```
kyc-adk-agent/
│
├── main_mock.py          ← run this first (local dev CLI)
├── server.py             ← REST API server
├── notebook_runner.py    ← Jupyter notebook helper
├── kyc_notebook.ipynb    ← interactive notebook
├── requirements.txt
├── .env.example
│
└── src/                  ← all application code
    ├── agents/           ← the four ADK agents
    │   ├── coordinator.py
    │   ├── document_fetcher.py
    │   ├── doc_classifier.py
    │   ├── checklist_matcher.py
    │   └── storage_agent.py
    │
    ├── tools/            ← functions the agents call
    │   ├── document_api_tools.py
    │   ├── docai_tools.py
    │   ├── gcs_tools.py
    │   └── checklist_tools.py
    │
    ├── mocks/            ← local-dev replacements for external APIs
    │   ├── mock_document_api.py
    │   ├── mock_docai.py
    │   ├── mock_gcs.py
    │   └── router.py     ← picks real vs mock based on MOCK_MODE
    │
    ├── api/              ← FastAPI REST service
    │   ├── app.py
    │   ├── schemas.py
    │   ├── dependencies.py
    │   ├── client_repository.py
    │   └── routers/
    │
    ├── config/
    │   ├── settings.py       ← all env vars with defaults
    │   └── kyc_checklist.py  ← what docs each client type needs
    │
    ├── db_init.py        ← SQLite (local) / PostgreSQL (prod) connection
    ├── session_factory.py← ADK session service setup
    └── job_manager.py    ← job lifecycle (create, update, query)
```

## Quickstart

```bash
pip install -r requirements.txt
export GOOGLE_API_KEY=your-gemini-api-key
python main_mock.py
```

That's it. SQLite is created automatically. External APIs are mocked.

See `RUNNING.md` for full instructions.
