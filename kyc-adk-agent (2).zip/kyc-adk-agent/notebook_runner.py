"""
notebook_runner.py
==================
All KYC pipeline logic for local/Jupyter development lives here.
The notebook (kyc_notebook.ipynb) imports and calls this file — it contains
no logic itself, just thin `await run_audit(client_id)` calls.

This means:
  - You write and refactor code in IntelliJ with full IDE support
  - The notebook is just a UI for triggering runs and viewing output
  - Hot-reload: changes here take effect on the next cell execution
    (no kernel restart needed if you use `importlib.reload` — see notebook)

Usage from notebook:
    from notebook_runner import NotebookRunner
    runner = NotebookRunner()
    state = await runner.run("CLI123456")
"""

import logging
import os
import sys
from pathlib import Path
from typing import Optional

# Add src/ to path so imports resolve from anywhere (notebook or terminal)
sys.path.insert(0, str(Path(__file__).parent / "src"))

from google.adk.agents import LlmAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai.types import Content, Part

from agents.kyc_pipeline_agent import KycPipelineAgent
from agents.document_fetcher import document_fetcher_agent
from agents.doc_classifier import doc_classifier_agent
from agents.checklist_matcher import checklist_matcher_agent
from agents.storage_agent import storage_agent
from mocks.mock_document_api import search_documents, download_document
from mocks.mock_docai import submit_classification_job, poll_classification_result
from mocks.mock_gcs import generate_document_name, upload_to_gcs
from tools.checklist_tools import load_kyc_checklist, generate_audit_report

logger = logging.getLogger(__name__)

APP_NAME      = "KYCAuditor-Notebook"
NOTEBOOK_USER = "notebook_dev"


class NotebookRunner:
    """
    Self-contained KYC pipeline runner for Jupyter/IntelliJ development.

    Holds the session service, job store, and pipeline instance.
    Instantiate once per kernel session; call run() for each client audit.

    Example:
        runner = NotebookRunner()
        state  = await runner.run("CLI123456")
        report = state.get("audit_report", {})
    """

    def __init__(self):
        self.session_service = InMemorySessionService()
        self.job_store: dict = {}
        self.pipeline = self._build_pipeline()
        self._runner = Runner(
            agent=self.pipeline,
            app_name=APP_NAME,
            session_service=self.session_service,
        )
        logger.info("NotebookRunner ready ✅")
        logger.info(f"  Pipeline : {self.pipeline.name}")
        for a in self.pipeline.sub_agents:
            logger.info(f"  Agent    : {a.name}")

    # ── Public API ────────────────────────────────────────────────────────────

    async def run(self, client_id: str) -> dict:
        """
        Run a full KYC audit for the given client.

        Creates a fresh session, streams all pipeline events, updates the
        in-memory job store, and returns the final session state dict.

        Args:
            client_id: e.g. "CLI123456" (individual) or "CORP789012" (corporate)

        Returns:
            Final session state dict with keys:
              fetched_documents, classified_documents,
              audit_report, stored_files,
              pipeline_aborted (if gate check fired)
        """
        session = await self.session_service.create_session(
            app_name=APP_NAME,
            user_id=NOTEBOOK_USER,
            state={"client_id": client_id},
        )
        session_id = session.id
        self._record_job(client_id, session_id)

        logger.info("=" * 55)
        logger.info(f"  CLIENT  : {client_id}")
        logger.info(f"  SESSION : {session_id}")
        logger.info("=" * 55)

        STATUS_MAP = {
            "DocumentFetcherAgent":  "FETCH_COMPLETE",
            "DocClassifierAgent":    "CLASSIFY_COMPLETE",
            "ChecklistMatcherAgent": "MATCH_COMPLETE",
            "StorageAgent":          "DONE",
        }

        try:
            async for event in self._runner.run_async(
                user_id=NOTEBOOK_USER,
                session_id=session_id,
                new_message=Content(
                    role="user",
                    parts=[Part(text=f"Run KYC audit for client {client_id}.")],
                ),
            ):
                author = getattr(event, "author", None)
                if author and getattr(event, "content", None):
                    for part in event.content.parts:
                        if getattr(part, "text", None):
                            print(f"  [{author}]  {part.text[:400]}")

                if author in STATUS_MAP and event.is_final_response():
                    self._update_job(client_id, STATUS_MAP[author])
                    logger.info(f"  ✅ {author} → {STATUS_MAP[author]}")

        except Exception as e:
            self._update_job(client_id, "FAILED", error=str(e))
            logger.error(f"Pipeline error: {e}", exc_info=True)
            raise

        # Retrieve and return final state
        final = await self.session_service.get_session(
            app_name=APP_NAME, user_id=NOTEBOOK_USER, session_id=session_id
        )
        state = final.state if final else {}

        if state.get("pipeline_aborted"):
            self._update_job(client_id, "FAILED",
                             abort_reason=state.get("abort_reason"))
            logger.error(f"  ⛔ ABORTED: {state.get('abort_reason')}")
        else:
            report = state.get("audit_report", {})
            self._update_job(client_id, "DONE",
                             kyc_status=report.get("overall_kyc_status"))

        return state

    def print_summary(self, state: dict) -> None:
        """Print a formatted audit summary from a state dict returned by run()."""
        if state.get("pipeline_aborted"):
            print(f"\n⛔  PIPELINE ABORTED")
            print(f"    Stage  : {state.get('abort_stage')}")
            print(f"    Reason : {state.get('abort_reason')}")
            return

        report  = state.get("audit_report", {})
        summary = report.get("summary", {})
        stored  = state.get("stored_files", [])
        W = 55
        print("\n" + "━" * W)
        print("  KYC AUDIT REPORT SUMMARY")
        print("━" * W)
        print(f"  Report ID           : {report.get('report_id', 'N/A')}")
        print(f"  Overall KYC status  : {report.get('overall_kyc_status', 'UNKNOWN')}")
        print(f"  Documents received  : {summary.get('total_documents_received', 0)}")
        print(f"  Matched             : {summary.get('matched', 0)}")
        print(f"  Missing (mandatory) : {summary.get('missing_mandatory', 0)}")
        print(f"  Low confidence      : {summary.get('low_confidence', 0)}")
        print(f"  Human review needed : {report.get('requires_human_review', False)}")
        print(f"  Files stored        : {len(stored)}")
        print("━" * W)

    def print_checklist(self, state: dict) -> None:
        """Print a formatted checklist table from a state dict."""
        checklist = state.get("audit_report", {}).get("checklist_results", [])
        ICON = {"PRESENT": "✅", "MISSING": "❌", "LOW_CONFIDENCE": "⚠️ ",
                "DUPLICATE": "🔁", "UNEXPECTED": "❓"}
        if not checklist:
            print("No checklist results.")
            return
        print(f"\n  {'Document Type':<42} {'Status':<18} Mandatory")
        print("  " + "-" * 72)
        for item in checklist:
            status = item.get("status", "UNKNOWN")
            print(f"  {item.get('required_document_type','?'):<42} "
                  f"{ICON.get(status,'  ')} {status:<15} "
                  f"{'✅ Yes' if item.get('is_mandatory') else '  No'}")

    def jobs(self) -> dict:
        """Return the current job store (all runs this session)."""
        return {cid: {k: v for k, v in job.items() if k != "events"}
                for cid, job in self.job_store.items()}

    # ── Private helpers ───────────────────────────────────────────────────────

    def _build_pipeline(self) -> KycPipelineAgent:
        """Build the agent pipeline with mock tools injected."""
        return KycPipelineAgent(
            name="KYCAuditorPipeline",
            description="KYC audit pipeline — notebook mode (real LLM, mock APIs)",
            sub_agents=[
                LlmAgent(
                    name=document_fetcher_agent.name,
                    model=document_fetcher_agent.model,
                    description=document_fetcher_agent.description,
                    instruction=document_fetcher_agent.instruction,
                    tools=[search_documents, download_document],
                ),
                LlmAgent(
                    name=doc_classifier_agent.name,
                    model=doc_classifier_agent.model,
                    description=doc_classifier_agent.description,
                    instruction=doc_classifier_agent.instruction,
                    tools=[submit_classification_job, poll_classification_result],
                ),
                LlmAgent(
                    name=checklist_matcher_agent.name,
                    model=checklist_matcher_agent.model,
                    description=checklist_matcher_agent.description,
                    instruction=checklist_matcher_agent.instruction,
                    tools=[load_kyc_checklist, generate_audit_report],
                ),
                LlmAgent(
                    name=storage_agent.name,
                    model=storage_agent.model,
                    description=storage_agent.description,
                    instruction=storage_agent.instruction,
                    tools=[generate_document_name, upload_to_gcs],
                ),
            ],
        )

    def _record_job(self, client_id: str, session_id: str) -> None:
        self.job_store[client_id] = {
            "session_id": session_id, "status": "PENDING", "events": []
        }

    def _update_job(self, client_id: str, status: str, **extra) -> None:
        if client_id in self.job_store:
            self.job_store[client_id]["status"] = status
            self.job_store[client_id].update(extra)
