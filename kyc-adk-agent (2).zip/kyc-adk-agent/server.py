"""
KYC Auditor — REST Service Entry Point
========================================
Starts uvicorn on port 8080.

Run:
  python server.py             # with real external APIs
  MOCK_MODE=true python server.py   # with mocked external APIs + SQLite
"""

import asyncio
import logging
import sys
from pathlib import Path

# Add src/ to path so all internal modules resolve without a src. prefix
sys.path.insert(0, str(Path(__file__).parent / "src"))

import uvicorn
from api.app import app

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
logger = logging.getLogger(__name__)


async def _main() -> None:
    config = uvicorn.Config(
        app=app, host="0.0.0.0", port=8080,
        workers=1, log_level="info", access_log=True,
    )
    server = uvicorn.Server(config)
    await server.serve()


if __name__ == "__main__":
    asyncio.run(_main())
