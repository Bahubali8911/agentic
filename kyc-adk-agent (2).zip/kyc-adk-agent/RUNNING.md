# KYC Auditor — Running Instructions

## Local Development

No cloud account, no Docker, no PostgreSQL needed. The app uses **SQLite** as
its real database locally — all session state, job tracking, and audit logs
are persisted to `kyc_local.db` in the project root.

External APIs (DocAI, GCS, Document API) are still mocked when `MOCK_MODE=true`.
The LLM (Gemini) is always real and requires `GOOGLE_API_KEY`.

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Set environment variables

The only required variable for local dev is your Gemini API key:

```bash
export GOOGLE_API_KEY=your-gemini-api-key

# Everything else has sensible defaults:
# DATABASE_URL  → sqlite+aiosqlite:///./kyc_local.db  (auto)
# MOCK_MODE     → false (set true to mock external APIs)
```

Or create a `.env` file:

```bash
GOOGLE_API_KEY=your-gemini-api-key
MOCK_MODE=true
```

### 3a. Run the CLI (quickest)

```bash
python main_mock.py CLI123456        # individual client
python main_mock.py CORP789012       # corporate client
```

On first run, `kyc_local.db` is created automatically with all tables.
The full four-agent pipeline runs with mocked external APIs.

Run the same command again to test **resume behaviour** — the existing
incomplete session will be picked up.

Inspect the database after a run:

```bash
sqlite3 kyc_local.db "SELECT client_id, status, kyc_overall_status, updated_at FROM kyc_audit_jobs;"
sqlite3 kyc_local.db "SELECT event_type, agent_name, logged_at FROM kyc_audit_log LIMIT 20;"
sqlite3 kyc_local.db ".tables"
```

Reset everything:

```bash
rm kyc_local.db
```

### 3b. Run the REST service locally

Insert a test client first (only needed once — persists in `kyc_local.db`):

```bash
python - << 'PY'
import asyncio, sqlalchemy as sa
from sqlalchemy.ext.asyncio import create_async_engine
from datetime import datetime

async def seed():
    engine = create_async_engine("sqlite+aiosqlite:///./kyc_local.db")
    async with engine.begin() as conn:
        await conn.execute(sa.text("""
            INSERT OR IGNORE INTO clients
              (client_id, full_name, client_type, email, risk_rating,
               relationship_manager, created_at, updated_at)
            VALUES
              ('CLI123456','James Thornton','INDIVIDUAL','james@example.com',
               'MEDIUM','Sarah Chen', datetime('now'), datetime('now'))
        """))
    await engine.dispose()
    print("Client seeded ✅")

asyncio.run(seed())
PY
```

Start the server:

```bash
MOCK_MODE=true python server.py
```

The server starts on `http://localhost:8080`. SQLite tables are created
automatically on first startup.

Trigger an audit:

```bash
curl -s -X POST http://localhost:8080/audits \
  -H "Content-Type: application/json" \
  -d '{"client_id": "CLI123456"}' | python3 -m json.tool
```

Poll for status (every 10–15s until DONE):

```bash
curl -s http://localhost:8080/audits/CLI123456/latest | python3 -m json.tool
```

Other endpoints:

```bash
curl http://localhost:8080/health
curl http://localhost:8080/clients/CLI123456
curl http://localhost:8080/audits/CLI123456
# Interactive docs:
open http://localhost:8080/docs
```

---

## Production (GKE + Cloud SQL)

### Prerequisites

- GKE cluster
- Cloud SQL PostgreSQL 15+ instance
- GCS bucket for audit reports
- Artifact Registry repository
- Service account: `Cloud SQL Client` + `Storage Object Admin` (bucket-scoped)

### Step 1 — Build and push image

```bash
PROJECT=your-gcp-project
REGION=europe-west3
VERSION=v1.0.0
IMAGE="${REGION}-docker.pkg.dev/${PROJECT}/kyc-auditor/kyc-auditor:${VERSION}"

docker build -t $IMAGE .
docker push $IMAGE
```

### Step 2 — Create Kubernetes secrets

```bash
kubectl create namespace kyc

kubectl create secret generic kyc-db-secret \
  --from-literal=database-url='postgresql+asyncpg://kyc_user:PASSWORD@127.0.0.1:5432/kycdb' \
  --namespace=kyc

kubectl create secret generic kyc-api-secrets \
  --from-literal=document-api-key='YOUR_KEY' \
  --from-literal=docai-api-key='YOUR_KEY' \
  --from-literal=google-api-key='YOUR_GEMINI_KEY' \
  --namespace=kyc
```

### Step 3 — Run migration (PostgreSQL only)

```bash
python migrate.py
```

Or it runs automatically as a Helm pre-install Job.

### Step 4 — Deploy with Helm

```bash
helm upgrade --install kyc-auditor ./helm/kyc-auditor \
  --namespace kyc --create-namespace \
  --set image.tag=$VERSION
```

---

## Environment Variables

| Variable | Local default | Required in prod | Description |
|---|---|---|---|
| `GOOGLE_API_KEY` | — | Yes | Gemini API key |
| `DATABASE_URL` | `sqlite+aiosqlite:///./kyc_local.db` | Yes | PostgreSQL URL in prod |
| `MOCK_MODE` | `false` | No | `true` to mock external APIs |
| `GCP_PROJECT_ID` | `local-dev` | Yes | GCP project ID |
| `GCS_BUCKET_NAME` | `local-bucket` | Yes | GCS bucket for reports |
| `DOCUMENT_API_KEY` | `mock` | Yes | Document REST API key |
| `DOCAI_API_KEY` | `mock` | Yes | DocAI API key |
| `GEMINI_MODEL_DEFAULT` | `gemini-2.5-flash` | No | Model for fetch/classify agents |
| `GEMINI_MODEL_REASONING` | `gemini-2.5-pro` | No | Model for checklist matching |
| `MAX_JOB_RETRIES` | `3` | No | Worker retry limit per job |
| `DB_ECHO_SQL` | `false` | No | Log all SQL (dev only) |
