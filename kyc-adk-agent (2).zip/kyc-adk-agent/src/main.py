"""
KYC Auditor — Production Entry Point
======================================
Startup order (strictly enforced):

  STEP 1: Connect to Cloud SQL + verify all tables exist  (db_init)
          Tables must already exist — run migrate.py before first deploy.
          Retries with backoff for Cloud SQL Auth Proxy sidecar startup lag.
  STEP 2: Create ADK DatabaseSessionService               (session_factory)
  STEP 3: Resolve session — resume or start fresh         (job_manager)
  STEP 4: Run the KYC pipeline                            (runner)

Crash recovery:
  If the pod restarts mid-audit, Step 3 detects the incomplete job
  and resumes from the last checkpoint using the persisted session_id.

Liveness probe:
  Writes /tmp/heartbeat at each pipeline stage transition.
  The K8s liveness probe checks this file's mtime — if it hasn't been
  updated in 5 minutes the pod is considered hung and restarted.

Usage:
  python main.py CLI123456
  python main.py CORP789012
"""

import asyncio
import logging
import os
import sys
from pathlib import Path

from google.adk.runners import Runner
from google.genai.types import Content, Part

from agents.coordinator import kyc_pipeline
from config.settings import settings
from db_init import connect_and_verify
from session_factory import create_session_service
from job_manager import KycJobManager

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
logger = logging.getLogger(__name__)
APP_NAME = "KYCAuditor"
HEARTBEAT_FILE = Path("/tmp/heartbeat")


def _touch_heartbeat() -> None:
    """Update /tmp/heartbeat mtime. Read by the K8s liveness probe."""
    HEARTBEAT_FILE.touch()


async def run_kyc_audit(client_id: str) -> dict:

    # ── STEP 1: Connect to DB + verify tables ─────────────────────────────────
    logger.info("STEP 1: Connecting to Cloud SQL and verifying tables...")
    _touch_heartbeat()
    async_engine = await connect_and_verify(max_retries=10, retry_delay_seconds=3.0)
    logger.info("STEP 1: Complete ✅")

    # ── STEP 2: Create ADK session service ────────────────────────────────────
    logger.info("STEP 2: Creating ADK DatabaseSessionService...")
    session_service = create_session_service()
    job_manager = KycJobManager(async_engine)
    logger.info("STEP 2: Complete ✅")

    # ── STEP 3: Resolve session ───────────────────────────────────────────────
    logger.info(f"STEP 3: Resolving session for client {client_id}...")
    session_id = await _resolve_session(client_id, job_manager, session_service)
    logger.info("STEP 3: Complete ✅")

    # ── STEP 4: Run pipeline ──────────────────────────────────────────────────
    logger.info(f"STEP 4: Running pipeline | client={client_id} | session={session_id}")
    _touch_heartbeat()
    await job_manager.log_event(client_id, session_id, "PIPELINE_STARTED", "KYCAuditorPipeline")

    runner = Runner(agent=kyc_pipeline, app_name=APP_NAME, session_service=session_service)

    STATUS_MAP = {
        "DocumentFetcherAgent":  "FETCH_COMPLETE",
        "DocClassifierAgent":    "CLASSIFY_COMPLETE",
        "ChecklistMatcherAgent": "MATCH_COMPLETE",
        "StorageAgent":          "DONE",
    }

    final_state = {}
    try:
        async for event in runner.run_async(
            user_id="system",
            session_id=session_id,
            new_message=Content(
                role="user",
                parts=[Part(text=f"Run full KYC audit for client {client_id}.")],
            ),
        ):
            author = getattr(event, "author", None)
            if author and getattr(event, "content", None):
                for part in event.content.parts:
                    if getattr(part, "text", None):
                        logger.info(f"[{author}] {part.text[:200]}")

            if author in STATUS_MAP and event.is_final_response():
                _touch_heartbeat()   # keep liveness probe happy during long runs
                await job_manager.update_status(session_id, STATUS_MAP[author])
                await job_manager.log_event(
                    client_id, session_id, STATUS_MAP[author], author
                )

        final_session = await session_service.get_session(
            app_name=APP_NAME, user_id="system", session_id=session_id
        )
        final_state = final_session.state if final_session else {}

        if final_state.get("pipeline_aborted"):
            abort_reason = final_state.get("abort_reason", "Unknown")
            abort_stage  = final_state.get("abort_stage", "Unknown")
            logger.error(f"Pipeline aborted at {abort_stage}: {abort_reason}")
            await job_manager.update_status(
                session_id, "FAILED",
                error_message=f"ABORTED at {abort_stage}: {abort_reason}"
            )
            await job_manager.log_event(
                client_id, session_id, "PIPELINE_ABORTED", "KYCAuditorPipeline",
                {"abort_reason": abort_reason, "abort_stage": abort_stage},
            )
        else:
            report = final_state.get("audit_report", {})
            stored = final_state.get("stored_files", [])

            # audit_report is stored directly (not nested) — see checklist_tools.py
            gcs_report_uri = next(
                (f["gcs_uri"] for f in stored
                 if f.get("document_type") == "AUDIT_REPORT"), None
            )

            await job_manager.update_status(
                session_id, "DONE",
                kyc_overall_status=report.get("overall_kyc_status"),
                total_documents=report.get("summary", {}).get("total_documents_received"),
                gcs_report_uri=gcs_report_uri,
            )
            await job_manager.log_event(
                client_id, session_id, "PIPELINE_COMPLETE", "KYCAuditorPipeline",
                {"kyc_status": report.get("overall_kyc_status"),
                 "gcs_report_uri": gcs_report_uri},
            )

    except Exception as e:
        logger.error(f"Pipeline failed: {e}", exc_info=True)
        await job_manager.update_status(session_id, "FAILED", error_message=str(e))
        await job_manager.log_event(
            client_id, session_id, "FAILED", "KYCAuditorPipeline", {"error": str(e)}
        )
        raise

    _print_summary(final_state)
    return final_state


async def _resolve_session(client_id, job_manager, session_service) -> str:
    """Resume an existing incomplete job, or create a fresh session."""
    existing_job = await job_manager.find_incomplete_job(client_id)

    if existing_job:
        session_id  = existing_job["session_id"]
        retry_count = await job_manager.increment_retry(session_id)

        if retry_count <= settings.MAX_JOB_RETRIES:
            existing_session = await session_service.get_session(
                app_name=APP_NAME, user_id="system", session_id=session_id
            )
            if existing_session:
                logger.info(
                    f"♻️  RESUMING | session={session_id} "
                    f"| last_status={existing_job['status']} | retry={retry_count}"
                )
                return session_id

        logger.warning(f"Job {session_id} not resumable — starting fresh.")
        await job_manager.update_status(
            session_id, "FAILED",
            error_message="Exceeded max retries or session lost"
        )

    new_session = await session_service.create_session(
        app_name=APP_NAME, user_id="system", state={"client_id": client_id}
    )
    session_id = new_session.id
    await job_manager.create_job(client_id, session_id)
    logger.info(f"🆕 NEW session | client={client_id} | session={session_id}")
    return session_id


def _print_summary(state: dict) -> None:
    report  = state.get("audit_report", {})
    summary = report.get("summary", {})
    stored  = state.get("stored_files", [])
    logger.info("=" * 55)
    logger.info(f"  KYC Status    : {report.get('overall_kyc_status', 'UNKNOWN')}")
    logger.info(f"  Report ID     : {report.get('report_id', 'N/A')}")
    logger.info(f"  Docs received : {summary.get('total_documents_received', 0)}")
    logger.info(f"  Matched       : {summary.get('matched', 0)}")
    logger.info(f"  Missing       : {summary.get('missing_mandatory', 0)}")
    logger.info(f"  Human review  : {report.get('requires_human_review', False)}")
    logger.info(f"  Files in GCS  : {len(stored)}")
    logger.info("=" * 55)


if __name__ == "__main__":
    client_id = sys.argv[1] if len(sys.argv) > 1 else "CLI123456"
    asyncio.run(run_kyc_audit(client_id))
