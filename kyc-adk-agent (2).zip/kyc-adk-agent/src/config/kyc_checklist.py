"""
KYC Checklist Configuration
Defines required documents per client type.
Extend this as your compliance requirements evolve.
"""

KYC_CHECKLISTS = {
    "INDIVIDUAL": [
        {
            "required_document_type": "PASSPORT",
            "is_mandatory": True,
            "description": "Valid government-issued passport (primary ID)",
            "max_allowed": 1,
            "alternatives": ["NATIONAL_ID", "DRIVERS_LICENSE"],
        },
        {
            "required_document_type": "PROOF_OF_ADDRESS",
            "is_mandatory": True,
            "description": "Utility bill or bank statement showing residential address (< 3 months)",
            "max_allowed": 2,
            "alternatives": [],
        },
        {
            "required_document_type": "BANK_STATEMENT",
            "is_mandatory": True,
            "description": "Bank statement from last 3 months",
            "max_allowed": 3,
            "alternatives": [],
        },
        {
            "required_document_type": "TAX_DOCUMENT",
            "is_mandatory": False,
            "description": "Tax identification document (e.g. W-9, W-8BEN)",
            "max_allowed": 1,
            "alternatives": [],
        },
        {
            "required_document_type": "SOURCE_OF_FUNDS",
            "is_mandatory": False,
            "description": "Evidence of source of funds (pay slips, investment statements)",
            "max_allowed": 5,
            "alternatives": [],
        },
    ],
    "CORPORATE": [
        {
            "required_document_type": "CERTIFICATE_OF_INCORPORATION",
            "is_mandatory": True,
            "description": "Certificate of incorporation or equivalent",
            "max_allowed": 1,
            "alternatives": ["ARTICLES_OF_ASSOCIATION"],
        },
        {
            "required_document_type": "MEMORANDUM_OF_ASSOCIATION",
            "is_mandatory": True,
            "description": "Memorandum and articles of association",
            "max_allowed": 1,
            "alternatives": [],
        },
        {
            "required_document_type": "REGISTER_OF_DIRECTORS",
            "is_mandatory": True,
            "description": "Current register of directors",
            "max_allowed": 1,
            "alternatives": [],
        },
        {
            "required_document_type": "REGISTER_OF_SHAREHOLDERS",
            "is_mandatory": True,
            "description": "Current register of shareholders / UBO declaration",
            "max_allowed": 1,
            "alternatives": [],
        },
        {
            "required_document_type": "AUDITED_FINANCIALS",
            "is_mandatory": True,
            "description": "Most recent audited financial statements",
            "max_allowed": 2,
            "alternatives": ["MANAGEMENT_ACCOUNTS"],
        },
        {
            "required_document_type": "PROOF_OF_REGISTERED_ADDRESS",
            "is_mandatory": True,
            "description": "Proof of registered office address",
            "max_allowed": 1,
            "alternatives": [],
        },
        {
            "required_document_type": "PASSPORT",
            "is_mandatory": True,
            "description": "Passport of each Ultimate Beneficial Owner (UBO)",
            "max_allowed": 10,
            "alternatives": ["NATIONAL_ID"],
        },
        {
            "required_document_type": "BOARD_RESOLUTION",
            "is_mandatory": False,
            "description": "Board resolution authorising account opening",
            "max_allowed": 1,
            "alternatives": [],
        },
    ],
}
