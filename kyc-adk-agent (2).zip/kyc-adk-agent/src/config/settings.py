"""
Application Settings
=====================
All values loaded from environment variables or .env file.

Database auto-detection:
  If DATABASE_URL is not set, defaults to SQLite at ./kyc_local.db
  This means you can run locally with zero environment setup beyond GOOGLE_API_KEY.

  SQLite   → local dev, no infrastructure needed
  PostgreSQL (postgresql+asyncpg://...) → staging / production on Cloud SQL

Required in production:
  GOOGLE_API_KEY        — Gemini API key (always required, even locally)
  DATABASE_URL          — leave unset to use SQLite automatically
  DOCUMENT_API_KEY      — Document REST API key
  DOCAI_API_KEY         — DocAI wrapper API key
  GCP_PROJECT_ID        — GCP project
  GCS_BUCKET_NAME       — GCS bucket for storing KYC documents
"""

from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):

    # ── Always required ────────────────────────────────────────────────────────
    GOOGLE_API_KEY: str = Field(..., description="Gemini API key")

    # ── Database — defaults to local SQLite ───────────────────────────────────
    # Leave unset locally → SQLite file created automatically in project root.
    # Set to postgresql+asyncpg://... for staging/production.
    DATABASE_URL: str = Field(
        default="sqlite+aiosqlite:///./kyc_local.db",
        description=(
            "DB connection URL. "
            "Defaults to sqlite+aiosqlite:///./kyc_local.db for local dev. "
            "Set to postgresql+asyncpg://user:pass@host:port/db for production."
        ),
    )

    # ── External APIs — optional for MOCK_MODE=true ───────────────────────────
    DOCUMENT_API_KEY:      str = Field(default="mock", description="Document REST API key")
    DOCAI_API_KEY:         str = Field(default="mock", description="DocAI wrapper API key")
    GCP_PROJECT_ID:        str = Field(default="local-dev", description="GCP project ID")
    GCS_BUCKET_NAME:       str = Field(default="local-bucket", description="GCS bucket name")

    DOCUMENT_API_BASE_URL: str = "https://your-document-api.example.com/v1"
    DOCAI_API_BASE_URL:    str = "https://your-docai-api.example.com/v1"

    # ── Model selection ────────────────────────────────────────────────────────
    GEMINI_MODEL_DEFAULT:   str = "gemini-2.5-flash"
    GEMINI_MODEL_REASONING: str = "gemini-2.5-pro"

    # ── DB pool (ignored for SQLite) ───────────────────────────────────────────
    DB_POOL_SIZE:    int  = 5
    DB_MAX_OVERFLOW: int  = 10
    DB_ECHO_SQL:     bool = False  # set True to log all SQL (dev only)

    # ── Pipeline behaviour ─────────────────────────────────────────────────────
    CLASSIFICATION_CONFIDENCE_THRESHOLD: float = 0.7
    MAX_JOB_RETRIES:              int = 3
    DOCAI_POLL_TIMEOUT_SECONDS:   int = 60

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
