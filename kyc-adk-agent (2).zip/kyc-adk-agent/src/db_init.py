"""
Database Connection + Table Initialisation
============================================
Supports both SQLite (local dev) and PostgreSQL (production) from the
same code path. The driver is detected from DATABASE_URL automatically.

SQLite   (sqlite+aiosqlite://...)  — created and migrated automatically.
                                     No setup needed. Tables created on
                                     first startup if they don't exist.

PostgreSQL (postgresql+asyncpg://) — tables must be created first by
                                     running migrate.py (production rule:
                                     apps don't migrate their own schema).

This file owns:
  - Table metadata (single source of truth for column definitions)
  - connect_and_verify() — called at startup by app.py and main.py
  - Auto-creation for SQLite (dev convenience)
  - Strict verification for PostgreSQL (prod safety)

Startup order (unchanged):
  STEP 1: connect_and_verify()        ← this file
  STEP 2: create_session_service()    ← session_factory.py
  STEP 3: resolve session             ← job_manager.py
  STEP 4: run pipeline
"""

import asyncio
import logging

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import create_async_engine, AsyncEngine
from sqlalchemy import text, event

from config.settings import settings

logger = logging.getLogger(__name__)

# ── Table metadata ────────────────────────────────────────────────────────────
# Single source of truth. job_manager.py imports these table objects for queries.
# create_all() is called only from within this module (for SQLite) or migrate.py.

metadata = sa.MetaData()

kyc_audit_jobs = sa.Table(
    "kyc_audit_jobs",
    metadata,
    sa.Column("id",                  sa.Integer,      primary_key=True, autoincrement=True),
    sa.Column("client_id",           sa.String(255),  nullable=False),
    sa.Column("session_id",          sa.String(255),  nullable=False, unique=True),
    sa.Column("status",              sa.String(50),   nullable=False, default="QUEUED",
              comment="QUEUED|RUNNING|FETCH_COMPLETE|CLASSIFY_COMPLETE|MATCH_COMPLETE|DONE|FAILED"),
    sa.Column("kyc_overall_status",  sa.String(20),   nullable=True),
    sa.Column("total_documents",     sa.Integer,      nullable=True),
    sa.Column("gcs_report_uri",      sa.String(1024), nullable=True),
    sa.Column("gcs_signed_url",      sa.String(2048), nullable=True),
    sa.Column("error_message",       sa.Text,         nullable=True),
    sa.Column("retry_count",         sa.Integer,      nullable=False, default=0),
    sa.Column("llm_cost_units",      sa.Integer,      nullable=True),
    sa.Column("docai_request_count", sa.Integer,      nullable=True),
    sa.Column("created_at",          sa.DateTime,     nullable=False),
    sa.Column("updated_at",          sa.DateTime,     nullable=False),
)

kyc_audit_log = sa.Table(
    "kyc_audit_log",
    metadata,
    sa.Column("id",         sa.Integer,     primary_key=True, autoincrement=True),
    sa.Column("client_id",  sa.String(255), nullable=False),
    sa.Column("session_id", sa.String(255), nullable=False),
    sa.Column("event_type", sa.String(100), nullable=False),
    sa.Column("agent_name", sa.String(100), nullable=True),
    sa.Column("details",    sa.JSON,        nullable=True),
    sa.Column("logged_at",  sa.DateTime,    nullable=False),
)

# Required tables — must all exist before the app accepts requests.
# sessions and events are created by ADK's DatabaseSessionService on first use.
REQUIRED_TABLES = ["sessions", "events", "kyc_audit_jobs", "kyc_audit_log", "clients"]

# Required tables for SQLite local dev — clients is optional (seeded manually)
REQUIRED_TABLES_SQLITE = ["kyc_audit_jobs", "kyc_audit_log", "clients"]


def _is_sqlite(url: str) -> bool:
    return url.startswith("sqlite")


def _is_postgres(url: str) -> bool:
    return "postgresql" in url or "postgres" in url


# ── Engine factory ────────────────────────────────────────────────────────────

def _make_engine(url: str) -> AsyncEngine:
    """
    Create an AsyncEngine appropriate for the given DB URL.

    SQLite:     aiosqlite driver, check_same_thread=False, no pool sizing
                (SQLite is file-based, pool_size is meaningless)
    PostgreSQL: asyncpg driver, connection pool, command_timeout, UTC timezone
    """
    if _is_sqlite(url):
        engine = create_async_engine(
            url,
            echo=settings.DB_ECHO_SQL,
            connect_args={"check_same_thread": False},
        )
        # Enable WAL mode and foreign keys for SQLite (runs once per connection)
        @event.listens_for(engine.sync_engine, "connect")
        def _on_connect(dbapi_conn, _):
            dbapi_conn.execute("PRAGMA journal_mode=WAL")
            dbapi_conn.execute("PRAGMA foreign_keys=ON")

        return engine

    # PostgreSQL
    return create_async_engine(
        url,
        echo=settings.DB_ECHO_SQL,
        pool_size=settings.DB_POOL_SIZE,
        max_overflow=settings.DB_MAX_OVERFLOW,
        pool_pre_ping=True,
        pool_recycle=1800,
        connect_args={
            "command_timeout": 30,
            "server_settings": {"timezone": "UTC"},
        },
    )


# ── connect_and_verify ────────────────────────────────────────────────────────

async def connect_and_verify(
        max_retries:         int   = 10,
        retry_delay_seconds: float = 3.0,
) -> AsyncEngine:
    """
    Connect to the database and ensure all required tables exist.

    SQLite:     Tables created automatically on first run — no migrate.py needed.
    PostgreSQL: Tables must already exist (run migrate.py before deploying).
                Retries with backoff for Cloud SQL Auth Proxy startup lag.

    Returns:
        AsyncEngine ready for use. Store on app.state for lifetime of process.

    Raises:
        RuntimeError — if connection fails after retries, or required tables
                       are missing (PostgreSQL only).
    """
    url = settings.DATABASE_URL
    logger.info("=" * 55)
    logger.info("  DATABASE CONNECTION")
    logger.info(f"  Driver: {'SQLite (local)' if _is_sqlite(url) else 'PostgreSQL (Cloud SQL)'}")
    if not _is_sqlite(url):
        logger.info(f"  Target: {_redacted_url(url)}")
    logger.info("=" * 55)

    if _is_sqlite(url):
        return await _connect_sqlite(url)
    else:
        return await _connect_postgres_with_retry(url, max_retries, retry_delay_seconds)


async def _connect_sqlite(url: str) -> AsyncEngine:
    """Connect to SQLite and auto-create all tables if they don't exist."""
    engine = _make_engine(url)

    async with engine.connect() as conn:
        await conn.execute(text("SELECT 1"))
    logger.info("SQLite connection OK ✅")

    # Auto-create our custom tables (kyc_audit_jobs, kyc_audit_log, clients)
    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all, checkfirst=True)

    # Also create clients table with all columns (for local dev convenience)
    await _ensure_clients_table(engine)

    # Trigger ADK to create sessions + events tables. Pass the aiosqlite URL
    # directly — ADK now uses create_async_engine internally, not the sync driver.
    _bootstrap_adk_tables(url)

    await _verify_tables(engine, required=REQUIRED_TABLES_SQLITE)
    logger.info("SQLite ready ✅")
    return engine


async def _connect_postgres_with_retry(
        url: str,
        max_retries: int,
        retry_delay_seconds: float,
) -> AsyncEngine:
    """Connect to PostgreSQL with retry for Cloud SQL Auth Proxy startup lag."""
    engine = None
    for attempt in range(1, max_retries + 1):
        try:
            logger.info(f"Connection attempt {attempt}/{max_retries}...")
            engine = _make_engine(url)
            async with engine.connect() as conn:
                await conn.execute(text("SELECT 1"))
            logger.info("Connected to Cloud SQL ✅")
            await _verify_tables(engine, required=REQUIRED_TABLES)
            logger.info("All tables verified ✅")
            return engine
        except Exception as e:
            logger.warning(f"Attempt {attempt}/{max_retries} failed: {e}")
            if engine:
                await engine.dispose()
                engine = None
            if attempt == max_retries:
                raise RuntimeError(
                    f"Cannot connect to Cloud SQL after {max_retries} attempts. "
                    f"Last error: {e}\n"
                    f"Hint: run 'python migrate.py' if tables are missing."
                )
            await asyncio.sleep(retry_delay_seconds)


async def _verify_tables(engine: AsyncEngine, required: list[str]) -> None:
    """
    Verify all required tables exist. Raises with a clear message if any are missing.

    Uses the appropriate introspection query for each DB type.
    """
    async with engine.connect() as conn:
        url = settings.DATABASE_URL
        if _is_sqlite(url):
            result = await conn.execute(
                text("SELECT name FROM sqlite_master WHERE type='table'")
            )
        else:
            result = await conn.execute(
                text("SELECT tablename FROM pg_tables WHERE schemaname='public'")
            )
        existing = {row[0] for row in result.fetchall()}

    missing = [t for t in required if t not in existing]
    if missing:
        raise RuntimeError(
            f"Required tables missing: {missing}\n"
            f"For PostgreSQL: run 'python migrate.py' before starting.\n"
            f"For SQLite: this should not happen — file a bug.\n"
            f"Existing: {sorted(existing)}"
        )
    logger.info(f"All required tables present: {required}")


async def _ensure_clients_table(engine: AsyncEngine) -> None:
    """
    Create the clients table in SQLite if it doesn't exist.
    For PostgreSQL this is handled by migrate.py.
    """
    clients_table = sa.Table(
        "clients", metadata,
        sa.Column("id",                   sa.Integer,     primary_key=True, autoincrement=True),
        sa.Column("client_id",            sa.String(255), nullable=False, unique=True),
        sa.Column("full_name",            sa.String(512), nullable=False),
        sa.Column("client_type",          sa.String(50),  nullable=False),
        sa.Column("email",                sa.String(255), nullable=True),
        sa.Column("phone",                sa.String(50),  nullable=True),
        sa.Column("nationality",          sa.String(100), nullable=True),
        sa.Column("date_of_birth",        sa.String(20),  nullable=True),
        sa.Column("company_name",         sa.String(512), nullable=True),
        sa.Column("registration_number",  sa.String(255), nullable=True),
        sa.Column("relationship_manager", sa.String(255), nullable=True),
        sa.Column("risk_rating",          sa.String(20),  nullable=True),
        sa.Column("onboarding_date",      sa.DateTime,    nullable=True),
        sa.Column("kyc_expiry_date",      sa.DateTime,    nullable=True),
        sa.Column("created_at",           sa.DateTime,    nullable=False),
        sa.Column("updated_at",           sa.DateTime,    nullable=False),
        extend_existing=True,
    )
    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all, checkfirst=True)


def _bootstrap_adk_tables(sqlite_url: str) -> None:
    """
    Instantiate ADK DatabaseSessionService so it creates sessions + events tables.
    ADK now uses create_async_engine internally, so it needs the aiosqlite URL
    (sqlite+aiosqlite:///) directly — not the old sync sqlite:/// scheme.
    """
    from google.adk.sessions import DatabaseSessionService
    DatabaseSessionService(db_url=sqlite_url)
    logger.info("ADK tables bootstrapped (sessions, events) ✅")


def _redacted_url(url: str) -> str:
    """Redact password from DB URL for safe logging."""
    try:
        from urllib.parse import urlparse, urlunparse
        parsed = urlparse(url)
        if parsed.password:
            redacted = parsed._replace(
                netloc=f"{parsed.username}:***@{parsed.hostname}:{parsed.port}"
            )
            return urlunparse(redacted)
    except Exception:
        pass
    return "<db_url>"