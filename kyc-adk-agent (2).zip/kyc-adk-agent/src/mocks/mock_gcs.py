"""
Mock: Google Cloud Storage
===========================
Replaces tools/gcs_tools.py for local dev/testing.

Instead of uploading to GCS, files are written to the local filesystem
under /tmp/mock-gcs/{bucket}/{folder}/ so you can inspect outputs without
any GCP credentials.

generate_document_name() is pure logic (no external calls) so it is
re-used directly from the real gcs_tools.py — only upload_to_gcs is mocked.
"""

import base64
import logging
import os
from datetime import datetime, timezone
from pathlib import Path

from config.settings import settings

logger = logging.getLogger(__name__)

# Local directory that simulates the GCS bucket
MOCK_GCS_ROOT = Path("/tmp/mock-gcs") / settings.GCS_BUCKET_NAME


def generate_document_name(
    client_id: str,
    document_type: str,
    original_filename: str,
    index: int,
) -> dict:
    """
    Pure logic — identical to the real implementation.
    Naming convention: {CLIENT_ID}_{DOCUMENT_TYPE}_{YYYYMMDD}_{INDEX:03d}.pdf
    """
    today = datetime.now(timezone.utc).strftime("%Y%m%d")
    safe_doc_type = document_type.upper().replace(" ", "_").replace("-", "_")
    standardized_filename = f"{client_id}_{safe_doc_type}_{today}_{index:03d}.pdf"

    logger.info(f"[MOCK] generate_document_name → {standardized_filename}")
    return {
        "success": True,
        "standardized_filename": standardized_filename,
        "gcs_folder": f"{client_id}/",
        "original_filename": original_filename,
    }


def upload_to_gcs(
    content_base64: str,
    destination_filename: str,
    folder: str = "",
) -> dict:
    """
    Mock: Writes the file to /tmp/mock-gcs/{bucket}/{folder}/{filename}
    instead of uploading to real GCS.

    Returns the same dict shape as the real upload_to_gcs so agents
    are completely unaware of the swap.
    """
    blob_path = f"{folder}/{destination_filename}" if folder else destination_filename
    local_path = MOCK_GCS_ROOT / blob_path

    logger.info(f"[MOCK] upload_to_gcs → {local_path}")

    try:
        # Ensure directory exists
        local_path.parent.mkdir(parents=True, exist_ok=True)

        # Decode base64 → bytes; fall back to plain text for JSON
        try:
            file_bytes = base64.b64decode(content_base64)
        except Exception:
            file_bytes = content_base64.encode("utf-8")

        local_path.write_bytes(file_bytes)

        # Fake gs:// URI (same format as real GCS)
        gcs_uri = f"gs://{settings.GCS_BUCKET_NAME}/{blob_path}"

        logger.info(
            f"[MOCK] upload_to_gcs ✅  {len(file_bytes)} bytes → {local_path}"
        )
        return {
            "success": True,
            "gcs_uri": gcs_uri,
            "blob_path": blob_path,
            "bytes_uploaded": len(file_bytes),
            "mock_local_path": str(local_path),
        }

    except Exception as e:
        logger.error(f"[MOCK] upload_to_gcs failed: {e}")
        return {
            "success": False,
            "gcs_uri": "",
            "error": str(e),
        }
