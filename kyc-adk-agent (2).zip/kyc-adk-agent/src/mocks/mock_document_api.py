"""
Mock: Document Fetch API
========================
Replaces tools/document_api_tools.py for local dev/testing.

Simulates a realistic set of 8 KYC documents for an INDIVIDUAL client
and 10 documents for a CORPORATE client, each with a download token.

Swap in via MOCK_MODE=true in settings — no code changes needed in agents.
"""

import base64
import logging
import os
import time

logger = logging.getLogger(__name__)

# ── Set MOCK_FAIL_SEARCH=true to simulate a total search failure ──────────────
# This triggers the pipeline gate check and halts after Agent 1.
# Usage:  MOCK_FAIL_SEARCH=true python main_mock.py CLI123456
MOCK_FAIL_SEARCH = os.getenv("MOCK_FAIL_SEARCH", "false").lower() == "true"

# ── Fake PDF bytes (minimal valid-ish PDF header) ─────────────────────────────
# Real PDFs would be large; we use a tiny stub so base64 stays small in logs.
def _fake_pdf_bytes(label: str) -> bytes:
    content = f"%PDF-1.4\n% Mock KYC Document: {label}\n%%EOF\n"
    return content.encode("utf-8")


def _fake_pdf_b64(label: str) -> str:
    return base64.b64encode(_fake_pdf_bytes(label)).decode("utf-8")


# ── Document catalogue per client type ───────────────────────────────────────
INDIVIDUAL_DOCUMENTS = [
    {"token": "TOK-IND-001", "filename": "passport_scan.pdf",          "doc_type_hint": "identity"},
    {"token": "TOK-IND-002", "filename": "utility_bill_jan.pdf",       "doc_type_hint": "address"},
    {"token": "TOK-IND-003", "filename": "bank_statement_q4.pdf",      "doc_type_hint": "financial"},
    {"token": "TOK-IND-004", "filename": "bank_statement_q3.pdf",      "doc_type_hint": "financial"},
    {"token": "TOK-IND-005", "filename": "tax_form_w9.pdf",            "doc_type_hint": "tax"},
    {"token": "TOK-IND-006", "filename": "salary_slip_dec.pdf",        "doc_type_hint": "income"},
    {"token": "TOK-IND-007", "filename": "investment_statement.pdf",   "doc_type_hint": "financial"},
    {"token": "TOK-IND-008", "filename": "random_scan_unreadable.pdf", "doc_type_hint": "unknown"},
]

CORPORATE_DOCUMENTS = [
    {"token": "TOK-CRP-001", "filename": "certificate_of_incorporation.pdf", "doc_type_hint": "corporate"},
    {"token": "TOK-CRP-002", "filename": "memorandum_of_association.pdf",    "doc_type_hint": "corporate"},
    {"token": "TOK-CRP-003", "filename": "register_of_directors.pdf",        "doc_type_hint": "corporate"},
    {"token": "TOK-CRP-004", "filename": "register_of_shareholders.pdf",     "doc_type_hint": "corporate"},
    {"token": "TOK-CRP-005", "filename": "audited_financials_2024.pdf",      "doc_type_hint": "financial"},
    {"token": "TOK-CRP-006", "filename": "registered_office_proof.pdf",      "doc_type_hint": "address"},
    {"token": "TOK-CRP-007", "filename": "ubo_passport_smith.pdf",           "doc_type_hint": "identity"},
    {"token": "TOK-CRP-008", "filename": "ubo_passport_jones.pdf",           "doc_type_hint": "identity"},
    {"token": "TOK-CRP-009", "filename": "board_resolution.pdf",             "doc_type_hint": "corporate"},
    {"token": "TOK-CRP-010", "filename": "misc_correspondence.pdf",          "doc_type_hint": "unknown"},
]

# Token → filename map for download lookup
_TOKEN_MAP = {d["token"]: d for d in INDIVIDUAL_DOCUMENTS + CORPORATE_DOCUMENTS}


# ── Mock tool functions (same signatures as real tools) ───────────────────────

def search_documents(client_id: str) -> dict:
    """
    Mock: Returns a fixed list of document tokens for the given client.
    CORPORATE clients (prefix CORP) get 10 docs; others get 8.
    Set MOCK_FAIL_SEARCH=true to simulate a total API failure (tests gate check).
    """
    logger.info(f"[MOCK] search_documents(client_id={client_id})")
    time.sleep(0.1)

    # Simulate a total search failure — triggers pipeline gate check
    if MOCK_FAIL_SEARCH:
        logger.warning("[MOCK] search_documents → SIMULATED FAILURE (MOCK_FAIL_SEARCH=true)")
        return {
            "success": False,
            "documents": [],
            "total_count": 0,
            "error": "503 Service Unavailable (simulated — MOCK_FAIL_SEARCH=true)",
        }

    docs = (
        CORPORATE_DOCUMENTS
        if client_id.upper().startswith("CORP")
        else INDIVIDUAL_DOCUMENTS
    )

    # Attach client_id to each document's metadata
    enriched = [
        {**d, "metadata": {"client_id": client_id, "upload_date": "2025-02-20"}}
        for d in docs
    ]

    logger.info(f"[MOCK] search_documents → {len(enriched)} documents found")
    return {
        "success": True,
        "documents": enriched,
        "total_count": len(enriched),
    }


def download_document(token: str) -> dict:
    """
    Mock: Returns fake PDF bytes for the given token.
    Simulates one occasional failure (TOK-IND-008 / TOK-CRP-010 always fails
    to test the agent's error handling).
    """
    logger.info(f"[MOCK] download_document(token={token})")
    time.sleep(0.05)  # Simulate per-document latency

    # Simulate a download failure for the last "unknown" document
    if token in ("TOK-IND-008", "TOK-CRP-010"):
        logger.warning(f"[MOCK] download_document → simulated failure for token {token}")
        return {
            "success": False,
            "content_base64": "",
            "filename": "",
            "error": "504 Gateway Timeout (simulated)",
        }

    doc = _TOKEN_MAP.get(token)
    if not doc:
        return {
            "success": False,
            "content_base64": "",
            "filename": "",
            "error": f"Token not found: {token}",
        }

    content_b64 = _fake_pdf_b64(doc["filename"])
    logger.info(f"[MOCK] download_document → {doc['filename']} ({len(content_b64)} b64 chars)")

    return {
        "success": True,
        "content_base64": content_b64,
        "filename": doc["filename"],
        "content_type": "application/pdf",
    }
