"""
Mock Router
============
Controls which external service implementations are active.

MOCK_MODE=true  — external APIs are mocked (no DocAI, no GCS, no Document API)
                  Database is ALWAYS real (SQLite locally, PostgreSQL in prod)
                  This is the key change: the DB is never mocked.

MOCK_MODE=false — all real implementations (production mode)

What is mocked in MOCK_MODE:
  ✅ Document API  → returns fake document tokens + PDF bytes
  ✅ DocAI         → classifies by filename pattern (PASSPORT, BANK_STATEMENT, etc.)
  ✅ GCS uploads   → writes to /tmp/mock-gcs/{bucket}/ instead of real GCS

What is NEVER mocked:
  ❌ Database      → always real (SQLite locally, PostgreSQL in prod)
                     This means job state, audit log, sessions are always persisted
                     and the full job lifecycle works correctly in local dev.
"""

import os
import logging

logger = logging.getLogger(__name__)

MOCK_MODE = os.getenv("MOCK_MODE", "false").lower() == "true"

if MOCK_MODE:
    logger.info("🟡 MOCK_MODE=true — external APIs mocked, DB is real (SQLite/PostgreSQL)")
    from mocks.mock_document_api import search_documents, download_document
    from mocks.mock_docai import submit_classification_job, poll_classification_result
    from mocks.mock_gcs import generate_document_name, upload_to_gcs
else:
    logger.info("🟢 MOCK_MODE=false — all real external services")
    from tools.document_api_tools import search_documents, download_document
    from tools.docai_tools import submit_classification_job, poll_classification_result
    from tools.gcs_tools import generate_document_name, upload_to_gcs

# Database is always real — same startup path for both modes
from db_init import connect_and_verify as init_database_fn
from session_factory import create_session_service as create_session_service_fn

__all__ = [
    "MOCK_MODE",
    "search_documents",
    "download_document",
    "submit_classification_job",
    "poll_classification_result",
    "generate_document_name",
    "upload_to_gcs",
    "init_database_fn",
    "create_session_service_fn",
]
