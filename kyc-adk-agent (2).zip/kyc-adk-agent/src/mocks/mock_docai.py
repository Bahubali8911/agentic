"""
Mock: DocAI Classification API (2-step submit + poll)
======================================================
Mirrors the real 2-step async pattern:
  1. submit_classification_job()  → returns job_id immediately
  2. poll_classification_result() → simulates variable processing time

Simulated processing delays per document (realistic range 5–30s):
  - passport / id:       ~5s   (fast)
  - bank statements:     ~10s  (medium)
  - corporate docs:      ~15s  (slow)
  - unknown/misc:        ~20s  (very slow, returns low confidence)

In mock mode time.sleep() durations are scaled down by MOCK_TIME_SCALE
(default 0.05) so a "20s" doc takes 1s real time, keeping tests fast.
"""

import logging
import time
import uuid
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

# Scale factor: 1.0 = real time, 0.05 = 20x faster for testing
MOCK_TIME_SCALE = 0.05

# ── In-memory job store ───────────────────────────────────────────────────────
# Maps job_id → { result, ready_at }
# ready_at is a timestamp — poll returns PENDING until that time is reached.
_JOB_STORE: dict[str, dict] = {}

# ── Filename keyword → (document_type, confidence, processing_seconds) ────────
CLASSIFICATION_RULES = [
    (["passport"],                           ("PASSPORT",                    0.97,  5)),
    (["national_id", "id_card"],             ("NATIONAL_ID",                 0.95,  5)),
    (["drivers", "driving"],                 ("DRIVERS_LICENSE",             0.93,  6)),
    (["certificate_of_incorporation",
      "incorporation"],                      ("CERTIFICATE_OF_INCORPORATION", 0.96, 15)),
    (["memorandum"],                         ("MEMORANDUM_OF_ASSOCIATION",    0.94, 15)),
    (["register_of_directors", "directors"], ("REGISTER_OF_DIRECTORS",       0.93, 12)),
    (["shareholders", "register_of_share"],  ("REGISTER_OF_SHAREHOLDERS",    0.92, 12)),
    (["board_resolution"],                   ("BOARD_RESOLUTION",            0.90, 10)),
    (["registered_office", "office_proof"],  ("PROOF_OF_REGISTERED_ADDRESS", 0.91, 10)),
    (["audited_financial", "audited"],       ("AUDITED_FINANCIALS",          0.95, 20)),
    (["bank_statement", "bank_stmt"],        ("BANK_STATEMENT",              0.94, 10)),
    (["investment_statement", "investment"], ("SOURCE_OF_FUNDS",             0.88, 12)),
    (["salary_slip", "payslip", "salary"],   ("SOURCE_OF_FUNDS",             0.85,  8)),
    (["utility_bill", "utility",
      "council_tax"],                        ("PROOF_OF_ADDRESS",            0.92,  7)),
    (["tax_form", "w9", "w8", "tax"],        ("TAX_DOCUMENT",               0.91,  8)),
    # Catch-all — slow + low confidence → triggers LOW_CONFIDENCE audit flag
    (["misc", "random", "unreadable",
      "correspondence", "unknown"],          ("UNKNOWN",                    0.35, 25)),
]


def submit_classification_job(content_base64: str, filename: str) -> dict:
    """
    Mock Step 1: Register a classification job and return a job_id immediately.

    The result is pre-computed now but marked as unavailable until
    `processing_seconds` (scaled) have elapsed — simulating async DocAI.

    Args:
        content_base64: Ignored in mock.
        filename: Used for keyword-based classification.

    Returns:
        Same shape as the real submit_classification_job.
    """
    logger.info(f"[MOCK] submit_classification_job(filename={filename})")

    # Determine result and simulated processing time from filename
    filename_lower = filename.lower()
    document_type, confidence, processing_seconds = "UNKNOWN", 0.30, 20

    for keywords, (doc_type, conf, proc_s) in CLASSIFICATION_RULES:
        if any(kw in filename_lower for kw in keywords):
            document_type, confidence, processing_seconds = doc_type, conf, proc_s
            break

    # Scale processing time for mock speed
    scaled_seconds = processing_seconds * MOCK_TIME_SCALE
    ready_at = time.monotonic() + scaled_seconds

    job_id = f"MOCK-JOB-{uuid.uuid4().hex[:8].upper()}"

    # Store the pre-computed result, gated by ready_at
    _JOB_STORE[job_id] = {
        "job_id": job_id,
        "filename": filename,
        "document_type": document_type,
        "confidence": confidence,
        "processing_seconds": processing_seconds,
        "scaled_seconds": scaled_seconds,
        "ready_at": ready_at,
        "submitted_at": time.monotonic(),
    }

    logger.info(
        f"[MOCK] Job {job_id} registered | "
        f"will be ready in ~{scaled_seconds:.1f}s (simulates {processing_seconds}s)"
    )

    return {
        "success": True,
        "job_id": job_id,
        "status": "PENDING",
    }


def poll_classification_result(job_id: str) -> dict:
    """
    Mock Step 2: Poll for the classification result.

    Returns PENDING/PROCESSING until the simulated processing time has elapsed,
    then returns COMPLETE with the pre-computed result.

    Internally uses the same exponential backoff loop as the real tool,
    but with scaled-down sleep times so tests complete quickly.

    Args:
        job_id: The job ID from submit_classification_job().

    Returns:
        Same shape as the real poll_classification_result.
    """
    logger.info(f"[MOCK] poll_classification_result(job_id={job_id})")

    if job_id not in _JOB_STORE:
        return {
            "success": False,
            "job_id": job_id,
            "status": "FAILED",
            "document_type": "UNKNOWN",
            "confidence": 0.0,
            "raw_response": {},
            "error": f"Unknown job_id: {job_id}",
        }

    job = _JOB_STORE[job_id]

    # Poll with backoff (scaled times for mock speed)
    max_poll_time = job["scaled_seconds"] + 2.0  # a little buffer
    wait = 0.3 * MOCK_TIME_SCALE  # scaled initial wait
    max_wait = 1.0 * MOCK_TIME_SCALE
    backoff = 1.5
    elapsed = 0.0
    attempt = 0

    while elapsed < max_poll_time + 5.0:
        now = time.monotonic()

        if now >= job["ready_at"]:
            # Job is ready — return result
            logger.info(
                f"[MOCK] Job {job_id} COMPLETE | "
                f"{job['document_type']} ({job['confidence']}) | "
                f"simulated {job['processing_seconds']}s processing"
            )
            return {
                "success": True,
                "job_id": job_id,
                "status": "COMPLETE",
                "document_type": job["document_type"],
                "confidence": job["confidence"],
                "raw_response": {
                    "job_id": job_id,
                    "document_type": job["document_type"],
                    "confidence": job["confidence"],
                    "mock": True,
                    "simulated_processing_seconds": job["processing_seconds"],
                    "filename": job["filename"],
                },
            }

        remaining = job["ready_at"] - now
        logger.info(
            f"[MOCK] Job {job_id} PROCESSING | "
            f"attempt={attempt + 1} | ~{remaining:.2f}s remaining (mock time)"
        )

        time.sleep(wait)
        elapsed += wait
        wait = min(wait * backoff, max_wait)
        attempt += 1

    # Should not reach here in normal operation
    logger.error(f"[MOCK] Job {job_id} TIMEOUT in mock poller")
    return {
        "success": False,
        "job_id": job_id,
        "status": "TIMEOUT",
        "document_type": "UNKNOWN",
        "confidence": 0.0,
        "raw_response": {},
        "error": "Mock poll timeout",
    }
