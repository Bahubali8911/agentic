"""
Session Service Factory
========================
Creates the ADK DatabaseSessionService with the correct URL for the
configured database.

SQLite (local dev):
  DATABASE_URL = sqlite+aiosqlite:///./kyc_local.db
  ADK URL      = sqlite+aiosqlite:///./kyc_local.db  (same — ADK uses async engine)

PostgreSQL (production):
  DATABASE_URL = postgresql+asyncpg://...
  ADK URL      = postgresql+asyncpg://...  (same — ADK uses async engine)

ADK's DatabaseSessionService now uses create_async_engine internally,
so it needs an async-driver URL in both cases. No URL conversion needed.
"""

import logging

from google.adk.sessions import DatabaseSessionService
from config.settings import settings

logger = logging.getLogger(__name__)

_session_service: DatabaseSessionService | None = None


def create_session_service() -> DatabaseSessionService:
    """
    Create the ADK DatabaseSessionService.

    Uses DATABASE_URL directly — ADK handles both SQLite (aiosqlite) and
    PostgreSQL (asyncpg) via its own async engine.

    For SQLite: creates sessions/events tables automatically on first call.
    For PostgreSQL: tables must already exist (created by migrate.py).
    """
    global _session_service

    url    = settings.DATABASE_URL
    driver = "SQLite (aiosqlite)" if "sqlite" in url else "PostgreSQL (asyncpg)"
    logger.info(f"Creating ADK DatabaseSessionService ({driver})...")

    _session_service = DatabaseSessionService(db_url=url)
    logger.info("ADK DatabaseSessionService ready ✅")
    return _session_service


def get_session_service() -> DatabaseSessionService:
    """Return the shared session service. Raises if not yet initialised."""
    if _session_service is None:
        raise RuntimeError(
            "Session service not initialised. "
            "Call create_session_service() at startup before serving requests."
        )
    return _session_service
