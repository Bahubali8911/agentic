"""
KYC Auditor — Root Pipeline
============================
Uses KycPipelineAgent (custom BaseAgent) instead of SequentialAgent
so we can gate-check after DocumentFetcherAgent and halt if it failed.

Pipeline order:
  1. DocumentFetcherAgent   → fetches all client documents
     ↓ GATE CHECK — if fetch failed, pipeline aborts here
  2. DocClassifierAgent     → classifies each doc via DocAI (submit + poll)
  3. ChecklistMatcherAgent  → matches docs to KYC checklist, produces report
  4. StorageAgent           → renames + uploads to GCS
"""

from agents.kyc_pipeline_agent import KycPipelineAgent
from agents.document_fetcher import document_fetcher_agent
from agents.doc_classifier import doc_classifier_agent
from agents.checklist_matcher import checklist_matcher_agent
from agents.storage_agent import storage_agent


kyc_pipeline = KycPipelineAgent(
    name="KYCAuditorPipeline",
    description=(
        "End-to-end KYC document audit pipeline. "
        "Fetches client documents, classifies them via DocAI, "
        "matches against the KYC checklist, and stores results in GCS. "
        "Halts immediately if document fetching fails."
    ),
    sub_agents=[
        document_fetcher_agent,
        doc_classifier_agent,
        checklist_matcher_agent,
        storage_agent,
    ],
)
