"""
Agent 1: Document Fetcher
Responsibility:
  - Search for documents using client_id via REST API → get tokens
  - Download each document one-by-one using the token
  - Store raw PDFs in session state for downstream agents
  - Set fetch_failed = True in state if the fetch cannot proceed
    so the pipeline gate check can halt cleanly
"""

from google.adk.agents import LlmAgent
from tools.document_api_tools import search_documents, download_document


document_fetcher_agent = LlmAgent(
    name="DocumentFetcherAgent",
    model="gemini-2.0-flash",
    description=(
        "Fetches all KYC documents for a given client. "
        "First calls the search API to retrieve document tokens, "
        "then downloads each document individually."
    ),
    instruction="""
You are the Document Fetcher agent in a KYC audit pipeline.

Your job:
1. Call `search_documents` with the `client_id` from session state.
   - This returns a list of document metadata objects, each containing a `token`.

2. CRITICAL — if `search_documents` fails or returns zero documents:
   - Set session state `fetch_failed = true`
   - Set session state `fetch_error` to the error message or "Search returned 0 documents"
   - Set session state `fetched_documents = []`
   - Set session state `total_documents_fetched = 0`
   - Stop immediately. Do NOT attempt any downloads.
   - Report the failure clearly.

3. If search succeeds, for each document token returned:
   - Call `download_document(token)` to retrieve the PDF bytes.
   - If a download fails for a specific token, log it and continue with the rest.
   - Do NOT set fetch_failed for individual download failures — only set it
     if the entire search step failed or zero documents were found.

4. After all downloads are attempted:
   - Store successfully downloaded documents in session state as `fetched_documents`.
     Each entry: { token, filename, content_base64, metadata }
   - Set session state `total_documents_fetched` to the count of successful downloads.
   - If ALL individual downloads failed (total_documents_fetched = 0), then also set
     `fetch_failed = true` and `fetch_error = "All document downloads failed"`.
   - Set session state `fetch_complete = true` only if at least 1 document was fetched.

5. Report the total fetched, and any individual failures with their tokens.
""",
    tools=[search_documents, download_document],
)
