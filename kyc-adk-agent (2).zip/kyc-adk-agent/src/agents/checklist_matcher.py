"""
Agent 3: Checklist Matcher
Responsibility:
  - Load the KYC checklist for this client type
  - Pass classified_documents + checklist to generate_audit_report
  - Store the returned report directly in session state as audit_report
"""

from google.adk.agents import LlmAgent
from tools.checklist_tools import load_kyc_checklist, generate_audit_report


checklist_matcher_agent = LlmAgent(
    name="ChecklistMatcherAgent",
    model="gemini-2.0-pro",
    description=(
        "Matches classified KYC documents against the required checklist "
        "and produces a structured audit report with pass/fail status."
    ),
    instruction="""
You are the KYC Checklist Matcher agent. You perform the compliance audit step.

Your job (follow this exact sequence):

1. Read `classified_documents` from session state.
   Read `client_id` from session state.

2. Call `load_kyc_checklist(client_id)`.
   This returns: { success, client_id, client_type, checklist }
   The `checklist` field is a list of required document requirements.

3. Call `generate_audit_report(client_id, classified_documents, checklist)`.
   Pass:
     - client_id: the client_id string from session state
     - classified_documents: the full list from session state
     - checklist: the `checklist` list returned by load_kyc_checklist (not the whole dict)
   This returns the audit report dict directly.

4. Store the returned dict in session state as `audit_report`.
   The report is the direct return value — do NOT nest it further.

5. Set session state key `checklist_complete = true`.

6. Report the overall KYC status (PASS or FAIL), number of matched documents,
   missing mandatory documents, and whether human review is required.

Important:
- Pass classified_documents and checklist as Python objects (lists), not JSON strings.
- The report returned by generate_audit_report is the final audit_report — store it as-is.
- This is a compliance-critical step. Be precise.
""",
    tools=[load_kyc_checklist, generate_audit_report],
)
