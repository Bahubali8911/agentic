"""
KYC Conditional Pipeline Agent
================================
A custom BaseAgent that runs the four KYC pipeline stages with gate checks
between each stage. Uses BaseAgent instead of SequentialAgent because
SequentialAgent provides no way to halt mid-pipeline.

Gate checks:
  After Agent 1 (DocumentFetcher):
    Halt if fetch_failed=True, fetched_documents missing/empty,
    or total_documents_fetched=0.

  After Agent 2 (DocClassifier):
    Halt if classified_documents missing or empty.
    (Prevents checklist matching and storage running on empty data.)

  After Agent 3 (ChecklistMatcher):
    Halt if audit_report missing or malformed.
    (Prevents storage agent storing an incomplete/missing report.)

On halt at any stage:
  - Sets pipeline_aborted = True in session state
  - Sets abort_reason with a human-readable explanation
  - Sets abort_stage with the agent name that triggered the abort
  - Yields a final error event — no further agents run
"""

import logging
from typing import AsyncGenerator

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions
from google.genai import types

logger = logging.getLogger(__name__)


class KycPipelineAgent(BaseAgent):
    """
    Conditional sequential pipeline for KYC auditing.

    Runs: DocumentFetcher → [gate] → DocClassifier → [gate]
          → ChecklistMatcher → [gate] → StorageAgent
    """

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:

        fetcher, classifier, matcher, storage = self.sub_agents

        # ── STAGE 1: Document Fetcher ─────────────────────────────────────────
        logger.info("[Pipeline] Stage 1: DocumentFetcherAgent starting...")
        async for event in fetcher.run_async(ctx):
            yield event

        # ── GATE 1: Fetch succeeded? ──────────────────────────────────────────
        abort_reason = _check_fetch_failure(ctx.session.state)
        if abort_reason:
            yield _abort(ctx, self.name, "DocumentFetcherAgent", abort_reason)
            return

        doc_count = len(ctx.session.state.get("fetched_documents", []))
        logger.info(f"[Pipeline] ✅ Gate 1 passed — {doc_count} documents fetched.")

        # ── STAGE 2: Document Classifier ─────────────────────────────────────
        logger.info("[Pipeline] Stage 2: DocClassifierAgent starting...")
        async for event in classifier.run_async(ctx):
            yield event

        # ── GATE 2: Classification produced results? ──────────────────────────
        abort_reason = _check_classification_failure(ctx.session.state)
        if abort_reason:
            yield _abort(ctx, self.name, "DocClassifierAgent", abort_reason)
            return

        classified_count = len(ctx.session.state.get("classified_documents", []))
        logger.info(f"[Pipeline] ✅ Gate 2 passed — {classified_count} documents classified.")

        # ── STAGE 3: Checklist Matcher ────────────────────────────────────────
        logger.info("[Pipeline] Stage 3: ChecklistMatcherAgent starting...")
        async for event in matcher.run_async(ctx):
            yield event

        # ── GATE 3: Audit report produced? ───────────────────────────────────
        abort_reason = _check_report_failure(ctx.session.state)
        if abort_reason:
            yield _abort(ctx, self.name, "ChecklistMatcherAgent", abort_reason)
            return

        logger.info("[Pipeline] ✅ Gate 3 passed — audit report generated.")

        # ── STAGE 4: Storage Agent ────────────────────────────────────────────
        logger.info("[Pipeline] Stage 4: StorageAgent starting...")
        async for event in storage.run_async(ctx):
            yield event

        logger.info("[Pipeline] ✅ All stages complete.")


# ── Gate check functions ──────────────────────────────────────────────────────

def _check_fetch_failure(state: dict) -> str | None:
    """Return abort reason string if fetch failed, else None."""
    if state.get("fetch_failed") is True:
        return f"fetch_failed=True. Detail: {state.get('fetch_error', 'No detail')}"
    if "fetched_documents" not in state:
        return "fetched_documents missing from state — agent may have crashed."
    if not state.get("fetched_documents"):
        return "fetched_documents is empty — search returned nothing or all downloads failed."
    if state.get("total_documents_fetched", 1) == 0:
        return "total_documents_fetched=0."
    return None


def _check_classification_failure(state: dict) -> str | None:
    """Return abort reason string if classification produced no results, else None."""
    if "classified_documents" not in state:
        return "classified_documents missing from state — DocClassifierAgent may have crashed."
    if not state.get("classified_documents"):
        return "classified_documents is empty — no documents were classified."
    return None


def _check_report_failure(state: dict) -> str | None:
    """Return abort reason string if audit report is missing or malformed, else None."""
    report = state.get("audit_report")
    if not report:
        return "audit_report missing from state — ChecklistMatcherAgent may have crashed."
    if "overall_kyc_status" not in report:
        return "audit_report is malformed — missing overall_kyc_status field."
    if "checklist_results" not in report:
        return "audit_report is malformed — missing checklist_results field."
    return None


def _abort(
    ctx: InvocationContext,
    pipeline_name: str,
    abort_stage: str,
    abort_reason: str,
) -> Event:
    """
    Write abort state and return a final error event.
    Called when any gate check fails.
    """
    logger.error(f"[Pipeline] ⛔ ABORTED at {abort_stage}: {abort_reason}")
    ctx.session.state["pipeline_aborted"] = True
    ctx.session.state["abort_reason"]     = abort_reason
    ctx.session.state["abort_stage"]      = abort_stage

    return Event(
        author=pipeline_name,
        content=types.Content(
            role="model",
            parts=[types.Part(text=(
                f"❌ KYC Pipeline aborted at {abort_stage}.\n"
                f"Reason: {abort_reason}\n"
                f"Downstream agents will NOT run."
            ))],
        ),
        actions=EventActions(escalate=False),
    )
