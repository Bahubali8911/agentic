"""
Tools for Agent 3: Checklist Matcher
Loads KYC checklists and generates the structured audit report.

Important: generate_audit_report returns the report dict directly (not nested
under a "report" key) so that session state["audit_report"] is the report
itself and callers like main.py can do state["audit_report"]["overall_kyc_status"]
without extra unwrapping.
"""

import json
import uuid
from datetime import datetime, timezone
from typing import TypedDict
from config.kyc_checklist import KYC_CHECKLISTS


class ClassifiedDocument(TypedDict):
    filename: str
    document_type: str
    confidence: float


class ChecklistItem(TypedDict):
    required_document_type: str
    is_mandatory: bool
    description: str
    max_allowed: int
    alternatives: list[str]


def load_kyc_checklist(client_id: str) -> dict:
    """
    Load the KYC document checklist for a given client.

    Args:
        client_id: The client identifier (used to determine client type).

    Returns:
        A dict containing:
          - success (bool)
          - client_id (str)
          - client_type (str): "INDIVIDUAL" or "CORPORATE"
          - checklist (list): Each item:
              { required_document_type, is_mandatory, description, max_allowed, alternatives }
    """
    client_type = _lookup_client_type(client_id)
    checklist = KYC_CHECKLISTS.get(client_type, KYC_CHECKLISTS["INDIVIDUAL"])

    return {
        "success": True,
        "client_id": client_id,
        "client_type": client_type,
        "checklist": checklist,
    }


def generate_audit_report(
        client_id: str,
        classified_documents: list[ClassifiedDocument],
        checklist: list[ChecklistItem],
) -> dict:
    """
    Generate a structured KYC audit report by matching classified documents
    against the required checklist.

    The agent passes classified_documents and checklist directly — this function
    performs all matching logic deterministically (no LLM reasoning needed here).

    Args:
        client_id:             The client identifier.
        classified_documents:  List of dicts with keys: filename, document_type, confidence.
        checklist:             List of required document dicts from load_kyc_checklist.

    Returns:
        The audit report dict directly — stored as session state["audit_report"].
        Keys: report_id, client_id, audit_timestamp, overall_kyc_status,
              summary, checklist_results, unexpected_documents, requires_human_review.
    """
    now = datetime.now(timezone.utc)
    confidence_threshold = 0.7

    # Build a lookup: document_type → list of classified docs of that type
    doc_by_type: dict[str, list] = {}
    for doc in classified_documents:
        dt = doc.get("document_type", "UNKNOWN")
        doc_by_type.setdefault(dt, []).append(doc)

    checklist_results = []
    matched_doc_types = set()

    for requirement in checklist:
        req_type  = requirement["required_document_type"]
        mandatory = requirement.get("is_mandatory", False)
        matches   = doc_by_type.get(req_type, [])

        if not matches:
            # Check alternatives
            alt_match = None
            for alt in requirement.get("alternatives", []):
                if doc_by_type.get(alt):
                    alt_match = doc_by_type[alt][0]
                    matched_doc_types.add(alt)
                    break

            if alt_match:
                conf = float(alt_match.get("confidence", 0.0))
                status = "PRESENT" if conf >= confidence_threshold else "LOW_CONFIDENCE"
                checklist_results.append({
                    "required_document_type": req_type,
                    "is_mandatory": mandatory,
                    "status": status,
                    "matched_filename": alt_match.get("filename"),
                    "matched_as_alternative": alt_match.get("document_type"),
                    "confidence": conf,
                })
            else:
                checklist_results.append({
                    "required_document_type": req_type,
                    "is_mandatory": mandatory,
                    "status": "MISSING",
                    "matched_filename": None,
                    "confidence": None,
                })
        elif len(matches) == 1:
            doc  = matches[0]
            conf = float(doc.get("confidence", 0.0))
            status = "PRESENT" if conf >= confidence_threshold else "LOW_CONFIDENCE"
            matched_doc_types.add(req_type)
            checklist_results.append({
                "required_document_type": req_type,
                "is_mandatory": mandatory,
                "status": status,
                "matched_filename": doc.get("filename"),
                "confidence": conf,
            })
        else:
            # Multiple docs of same type — first is PRESENT/LOW_CONFIDENCE, rest DUPLICATE
            max_allowed = requirement.get("max_allowed", 1)
            for i, doc in enumerate(matches):
                conf   = float(doc.get("confidence", 0.0))
                if i == 0:
                    status = "PRESENT" if conf >= confidence_threshold else "LOW_CONFIDENCE"
                elif i < max_allowed:
                    status = "PRESENT" if conf >= confidence_threshold else "LOW_CONFIDENCE"
                else:
                    status = "DUPLICATE"
                matched_doc_types.add(req_type)
                checklist_results.append({
                    "required_document_type": req_type,
                    "is_mandatory": mandatory,
                    "status": status,
                    "matched_filename": doc.get("filename"),
                    "confidence": conf,
                })

    # Unexpected documents — classified but not on checklist and not matched as alternative
    unexpected_documents = [
        {
            "filename":      doc.get("filename"),
            "document_type": doc.get("document_type"),
            "confidence":    doc.get("confidence"),
        }
        for doc in classified_documents
        if doc.get("document_type") not in matched_doc_types
           and doc.get("document_type") != "UNKNOWN"
    ]

    # Overall status: PASS only if all mandatory docs are PRESENT
    missing_mandatory = [
        r for r in checklist_results
        if r["is_mandatory"] and r["status"] == "MISSING"
    ]
    low_confidence = [r for r in checklist_results if r["status"] == "LOW_CONFIDENCE"]
    overall_status = "PASS" if not missing_mandatory else "FAIL"

    report = {
        "report_id":           f"KYC-{client_id}-{now.strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:6]}",
        "client_id":           client_id,
        "audit_timestamp":     now.isoformat(),
        "overall_kyc_status":  overall_status,
        "summary": {
            "total_documents_received": len(classified_documents),
            "matched":           sum(1 for r in checklist_results if r["status"] == "PRESENT"),
            "missing_mandatory": len(missing_mandatory),
            "low_confidence":    len(low_confidence),
            "duplicates":        sum(1 for r in checklist_results if r["status"] == "DUPLICATE"),
            "unexpected":        len(unexpected_documents),
        },
        "checklist_results":     checklist_results,
        "unexpected_documents":  unexpected_documents,
        "requires_human_review": bool(missing_mandatory or low_confidence or unexpected_documents),
    }

    # Return the report directly — not nested under "report" key
    # This means session state["audit_report"]["overall_kyc_status"] works directly
    return report


def _lookup_client_type(client_id: str) -> str:
    """
    Determine client type from client_id prefix.
    Replace with a real CRM/database lookup in production.
    """
    if client_id.upper().startswith("CORP"):
        return "CORPORATE"
    return "INDIVIDUAL"