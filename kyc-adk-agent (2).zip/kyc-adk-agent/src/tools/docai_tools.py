"""
Tools for Agent 2: DocClassifierAgent
=======================================
DocAI 2-step pattern:
  Step 1  submit_classification_job(content_base64, filename)
          POST /classify -> { job_id, status: "PENDING" }

  Step 2  poll_classification_result(job_id, file_size_bytes)
          GET /classify/{job_id} -> { status, document_type, confidence }
          Polls until COMPLETE | FAILED | TIMEOUT

Adaptive timeout (Improvement 2)
----------------------------------
A flat 60s timeout assumes all documents are simple. A 2-page passport
classifies in ~5s. A 200-page corporate financial statement can take 3+ min.

Timeout is now based on the file's actual byte size:
  < 100 KB  ->  60s   (passports, IDs, short letters)
  100KB–1MB -> 150s   (bank statements, longer reports)
  > 1 MB    -> 300s   (audited financials, board resolutions)

Exponential backoff uses jitter to prevent thundering-herd when many
documents complete simultaneously and all retry at the same instant.

sync vs async
-------------
These remain sync functions. ADK calls sync tools in a thread pool executor
so time.sleep() here blocks only the worker thread, not the event loop.
This is correct for sync ADK tools. See ADK docs on async tool support
before converting — the API changed between ADK versions.
"""

import random
import time
import logging
import base64

import httpx
from config.settings import settings

logger = logging.getLogger(__name__)

# ── Timeout tiers by file size ─────────────────────────────────────────────
_TIMEOUT_TIERS = [
    (100_000,   60),   # < 100KB  -> 60s
    (1_000_000, 150),  # < 1MB    -> 150s
    (float("inf"), 300),  # >= 1MB -> 300s
]


def _adaptive_timeout(content_base64: str) -> int:
    """
    Derive poll timeout in seconds from base64-encoded content size.
    Larger documents take longer to classify — a flat timeout causes
    false TIMEOUT failures on large files.
    """
    try:
        # base64 length * 3/4 approximates decoded byte size (no padding needed)
        approx_bytes = len(content_base64) * 3 // 4
    except Exception:
        return 60

    for threshold, timeout in _TIMEOUT_TIERS:
        if approx_bytes < threshold:
            logger.debug(
                f"DocAI timeout={timeout}s for approx {approx_bytes:,} bytes"
            )
            return timeout
    return 300


def submit_classification_job(content_base64: str, filename: str) -> dict:
    """
    Submit a document to DocAI for classification.

    Args:
        content_base64: Base64-encoded PDF content.
        filename:       Original filename — sent as metadata hint to DocAI.

    Returns:
        dict with: success, job_id, status, file_size_bytes, error (optional)
    """
    logger.info(f"Submitting DocAI job: {filename}")
    approx_bytes = len(content_base64) * 3 // 4

    try:
        response = httpx.post(
            f"{settings.DOCAI_API_BASE_URL}/classify",
            json={
                "content":   content_base64,
                "filename":  filename,
                "mime_type": "application/pdf",
            },
            headers={
                "Authorization": f"Bearer {settings.DOCAI_API_KEY}",
                "Content-Type":  "application/json",
            },
            timeout=30,
        )
        response.raise_for_status()
        data   = response.json()
        job_id = data.get("job_id")

        if not job_id:
            return {
                "success": False, "job_id": "", "status": "FAILED",
                "file_size_bytes": approx_bytes,
                "error": f"No job_id in response: {data}",
            }

        logger.info(
            f"DocAI submitted: job_id={job_id} file={filename} "
            f"~{approx_bytes:,} bytes"
        )
        return {
            "success":         True,
            "job_id":          job_id,
            "status":          data.get("status", "PENDING"),
            "file_size_bytes": approx_bytes,
        }

    except httpx.HTTPStatusError as e:
        return {"success": False, "job_id": "", "status": "FAILED",
                "file_size_bytes": approx_bytes, "error": str(e)}
    except Exception as e:
        return {"success": False, "job_id": "", "status": "FAILED",
                "file_size_bytes": approx_bytes, "error": str(e)}


def poll_classification_result(job_id: str, file_size_bytes: int = 0) -> dict:
    """
    Poll DocAI for the result of a submitted classification job.

    Uses adaptive timeout based on file size and exponential backoff
    with jitter to prevent thundering-herd on parallel documents.

    Args:
        job_id:          ID returned by submit_classification_job().
        file_size_bytes: Approximate decoded byte size — determines timeout tier.
                         Pass the file_size_bytes value from submit result.

    Backoff strategy:
      initial_wait: 2s
      multiplier:   1.5x per attempt
      cap:          12s per interval
      jitter:       ±20% of wait to spread retries across concurrent docs

    Returns:
        dict with: success, job_id, status, document_type, confidence,
                   raw_response, timeout_used_seconds, error (optional)
    """
    # Derive timeout from file_size_bytes if provided, else from settings default
    if file_size_bytes > 0:
        # Convert raw bytes to approximate base64 size for tier lookup
        approx_b64 = file_size_bytes * 4 // 3
        timeout_seconds = _adaptive_timeout("x" * approx_b64)
    else:
        timeout_seconds = settings.DOCAI_POLL_TIMEOUT_SECONDS

    logger.info(
        f"Polling DocAI job_id={job_id} "
        f"file_size~{file_size_bytes:,}B timeout={timeout_seconds}s"
    )

    elapsed  = 0.0
    wait     = 2.0    # initial wait — shorter than before (was 3s)
    max_wait = 12.0   # cap per interval
    backoff  = 1.5
    attempt  = 0

    while elapsed < timeout_seconds:
        # Jitter: ±20% of current wait to spread concurrent retries
        jitter       = wait * 0.2 * (random.random() * 2 - 1)
        sleep_time   = max(0.5, wait + jitter)

        logger.info(
            f"Poll attempt {attempt + 1} | job_id={job_id} "
            f"elapsed={elapsed:.1f}s sleep={sleep_time:.1f}s"
        )
        time.sleep(sleep_time)   # sync — safe in ADK thread pool
        elapsed += sleep_time

        try:
            response = httpx.get(
                f"{settings.DOCAI_API_BASE_URL}/classify/{job_id}",
                headers={"Authorization": f"Bearer {settings.DOCAI_API_KEY}"},
                timeout=15,
            )
            response.raise_for_status()
            data   = response.json()
            status = data.get("status", "UNKNOWN").upper()

            if status == "COMPLETE":
                logger.info(
                    f"DocAI COMPLETE: job_id={job_id} "
                    f"type={data.get('document_type')} "
                    f"confidence={data.get('confidence')} "
                    f"elapsed={elapsed:.1f}s"
                )
                return {
                    "success":              True,
                    "job_id":               job_id,
                    "status":               "COMPLETE",
                    "document_type":        data.get("document_type", "UNKNOWN"),
                    "confidence":           float(data.get("confidence", 0.0)),
                    "raw_response":         data,
                    "timeout_used_seconds": timeout_seconds,
                }

            if status == "FAILED":
                error_msg = data.get("error", "DocAI processing failed")
                logger.warning(f"DocAI FAILED: job_id={job_id} error={error_msg}")
                return {
                    "success":              False,
                    "job_id":               job_id,
                    "status":               "FAILED",
                    "document_type":        "UNKNOWN",
                    "confidence":           0.0,
                    "raw_response":         data,
                    "timeout_used_seconds": timeout_seconds,
                    "error":                error_msg,
                }

            logger.info(f"DocAI status={status} — continuing...")

        except httpx.HTTPStatusError as e:
            logger.warning(f"Poll HTTP error attempt {attempt + 1}: {e}")
        except Exception as e:
            logger.warning(f"Poll error attempt {attempt + 1}: {e}")

        wait     = min(wait * backoff, max_wait)
        attempt += 1

    logger.error(
        f"DocAI TIMEOUT after {elapsed:.1f}s "
        f"(tier={timeout_seconds}s) job_id={job_id}"
    )
    return {
        "success":              False,
        "job_id":               job_id,
        "status":               "TIMEOUT",
        "document_type":        "UNKNOWN",
        "confidence":           0.0,
        "raw_response":         {},
        "timeout_used_seconds": timeout_seconds,
        "error":                f"Timed out after {elapsed:.1f}s (limit={timeout_seconds}s)",
    }
