"""
Tools for Agent 1: Document Fetcher
Wraps the client document REST API.
"""

import base64
import httpx
from google.adk.tools import FunctionTool
from config.settings import settings


def search_documents(client_id: str) -> dict:
    """
    Search for all documents associated with a client.

    Args:
        client_id: The unique identifier of the KYC client.

    Returns:
        A dict containing:
          - success (bool)
          - documents (list): Each item has { token, filename, doc_type_hint, metadata }
          - total_count (int)
          - error (str, optional)
    """
    try:
        response = httpx.get(
            f"{settings.DOCUMENT_API_BASE_URL}/documents/search",
            params={"client_id": client_id},
            headers={"Authorization": f"Bearer {settings.DOCUMENT_API_KEY}"},
            timeout=30,
        )
        response.raise_for_status()
        data = response.json()

        return {
            "success": True,
            "documents": data.get("documents", []),
            "total_count": data.get("total_count", 0),
        }
    except httpx.HTTPStatusError as e:
        return {"success": False, "documents": [], "total_count": 0, "error": str(e)}
    except Exception as e:
        return {"success": False, "documents": [], "total_count": 0, "error": str(e)}


def download_document(token: str) -> dict:
    """
    Download a single document using its token.

    Args:
        token: The document download token from search_documents.

    Returns:
        A dict containing:
          - success (bool)
          - content_base64 (str): Base64-encoded PDF bytes
          - filename (str)
          - content_type (str)
          - error (str, optional)
    """
    try:
        response = httpx.post(
            f"{settings.DOCUMENT_API_BASE_URL}/documents/download",
            json={"token": token},
            headers={"Authorization": f"Bearer {settings.DOCUMENT_API_KEY}"},
            timeout=60,  # Documents can be large
        )
        response.raise_for_status()

        # Encode the raw PDF bytes to base64 for safe transport through session state
        content_base64 = base64.b64encode(response.content).decode("utf-8")

        # Try to get filename from Content-Disposition header
        content_disposition = response.headers.get("content-disposition", "")
        filename = token + ".pdf"
        if "filename=" in content_disposition:
            filename = content_disposition.split("filename=")[-1].strip('"')

        return {
            "success": True,
            "content_base64": content_base64,
            "filename": filename,
            "content_type": response.headers.get("content-type", "application/pdf"),
        }
    except httpx.HTTPStatusError as e:
        return {"success": False, "content_base64": "", "filename": "", "error": str(e)}
    except Exception as e:
        return {"success": False, "content_base64": "", "filename": "", "error": str(e)}
