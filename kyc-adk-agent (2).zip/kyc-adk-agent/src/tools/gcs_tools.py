"""
Tools for Agent 4: Storage Agent
Handles document renaming and GCS upload.

GCS client is a module-level singleton — created once, reused for all uploads
in a pipeline run. Creating a new client per call adds ~200ms auth overhead
and wastes connections.
"""

import base64
import logging
from datetime import datetime, timezone
from functools import lru_cache

from google.cloud import storage
from config.settings import settings

logger = logging.getLogger(__name__)


@lru_cache(maxsize=1)
def _get_gcs_client() -> storage.Client:
    """
    Return a cached GCS client. Created once per process, reused thereafter.
    lru_cache(maxsize=1) ensures only one instance exists — safe because
    google.cloud.storage.Client is thread-safe.
    """
    logger.info("Creating GCS client singleton...")
    return storage.Client(project=settings.GCP_PROJECT_ID)


def generate_document_name(
    client_id: str,
    document_type: str,
    original_filename: str,
    index: int,
) -> dict:
    """
    Generate a standardized document filename for GCS storage.

    Naming convention: {CLIENT_ID}_{DOCUMENT_TYPE}_{YYYYMMDD}_{INDEX:03d}.pdf
    Example: CLI123_PASSPORT_20250226_001.pdf

    Args:
        client_id:         The client identifier.
        document_type:     Classified document type (e.g. "PASSPORT").
        original_filename: Original filename (stored in metadata).
        index:             Document sequence number (1-based).

    Returns:
        A dict containing:
          - success (bool)
          - standardized_filename (str)
          - gcs_folder (str): {client_id}/
          - original_filename (str)
    """
    today = datetime.now(timezone.utc).strftime("%Y%m%d")
    safe_doc_type = document_type.upper().replace(" ", "_").replace("-", "_")
    standardized_filename = f"{client_id}_{safe_doc_type}_{today}_{index:03d}.pdf"

    return {
        "success": True,
        "standardized_filename": standardized_filename,
        "gcs_folder": f"{client_id}/",
        "original_filename": original_filename,
    }


def upload_to_gcs(
    content_base64: str,
    destination_filename: str,
    folder: str = "",
) -> dict:
    """
    Upload a document (base64-encoded) to Google Cloud Storage.

    Uses the module-level singleton GCS client — no per-call auth overhead.

    Args:
        content_base64:       Base64-encoded file content (PDF or JSON string).
        destination_filename: Target filename in GCS.
        folder:               Optional subfolder prefix (e.g. client_id).

    Returns:
        A dict containing:
          - success (bool)
          - gcs_uri (str): Full gs:// URI of the uploaded file
          - blob_path (str)
          - bytes_uploaded (int)
          - error (str, optional)
    """
    try:
        gcs_client = _get_gcs_client()          # singleton — no new client per call
        bucket = gcs_client.bucket(settings.GCS_BUCKET_NAME)

        blob_path = f"{folder}/{destination_filename}" if folder else destination_filename
        blob = bucket.blob(blob_path)

        # Decode base64 → bytes; if it fails, treat as plain text (JSON report)
        try:
            file_bytes = base64.b64decode(content_base64)
            content_type = "application/pdf"
        except Exception:
            file_bytes = content_base64.encode("utf-8")
            content_type = "application/json"

        blob.upload_from_string(file_bytes, content_type=content_type)

        gcs_uri = f"gs://{settings.GCS_BUCKET_NAME}/{blob_path}"
        logger.info(f"Uploaded: {gcs_uri} ({len(file_bytes):,} bytes)")

        return {
            "success": True,
            "gcs_uri": gcs_uri,
            "blob_path": blob_path,
            "bytes_uploaded": len(file_bytes),
        }

    except Exception as e:
        logger.error(f"GCS upload failed: {destination_filename} — {e}")
        return {
            "success": False,
            "gcs_uri": "",
            "error": str(e),
        }
