"""
KYC Job Manager
================
CRUD for kyc_audit_jobs and kyc_audit_log.

Job lifecycle (DB-queue model):
  QUEUED            -> written by POST /audits (API enqueues, doesn't execute)
  RUNNING           -> claimed atomically by worker (SKIP LOCKED)
  FETCH_COMPLETE    -> after DocumentFetcherAgent
  CLASSIFY_COMPLETE -> after DocClassifierAgent
  MATCH_COMPLETE    -> after ChecklistMatcherAgent
  DONE              -> after StorageAgent, signed URL stored
  FAILED            -> gate abort or unhandled exception

The database is the job queue. No Pub/Sub, no Redis required.
A pod restart means the next worker poll finds the QUEUED row and picks it up.
"""

import logging
from datetime import datetime, timezone
from typing import Optional

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncEngine

from db_init import kyc_audit_jobs, kyc_audit_log

logger = logging.getLogger(__name__)

PIPELINE_STAGES = [
    "QUEUED", "RUNNING",
    "FETCH_COMPLETE", "CLASSIFY_COMPLETE", "MATCH_COMPLETE",
    "DONE",
]


class KycJobManager:
    def __init__(self, engine: AsyncEngine):
        self.engine = engine

    # ── Job lifecycle ─────────────────────────────────────────────────────────

    async def create_job(self, client_id: str, session_id: str) -> int:
        """
        Insert a new QUEUED job row.
        Called by POST /audits after creating the ADK session.
        Returns the new job id.
        """
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        async with self.engine.begin() as conn:
            result = await conn.execute(
                kyc_audit_jobs.insert().values(
                    client_id=client_id,
                    session_id=session_id,
                    status="QUEUED",
                    retry_count=0,
                    created_at=now,
                    updated_at=now,
                )
            )
        job_id = result.inserted_primary_key[0]
        logger.info(f"Job queued: id={job_id} client={client_id}")
        return job_id

    async def update_status(
        self,
        session_id:          str,
        status:              str,
        *,
        kyc_overall_status:  Optional[str] = None,
        total_documents:     Optional[int] = None,
        gcs_report_uri:      Optional[str] = None,
        gcs_signed_url:      Optional[str] = None,   # NEW: short-TTL download URL
        error_message:       Optional[str] = None,
        docai_request_count: Optional[int] = None,   # NEW: cost tracking
    ) -> None:
        now    = datetime.now(timezone.utc).replace(tzinfo=None)
        values = {"status": status, "updated_at": now}
        if kyc_overall_status  is not None: values["kyc_overall_status"]  = kyc_overall_status
        if total_documents     is not None: values["total_documents"]      = total_documents
        if gcs_report_uri      is not None: values["gcs_report_uri"]       = gcs_report_uri
        if gcs_signed_url      is not None: values["gcs_signed_url"]       = gcs_signed_url
        if error_message       is not None: values["error_message"]        = error_message
        if docai_request_count is not None: values["docai_request_count"]  = docai_request_count

        async with self.engine.begin() as conn:
            await conn.execute(
                kyc_audit_jobs.update()
                .where(kyc_audit_jobs.c.session_id == session_id)
                .values(**values)
            )
        logger.info(f"Job [{session_id[:12]}...] → {status}")

    async def increment_retry(self, session_id: str) -> int:
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        async with self.engine.begin() as conn:
            result = await conn.execute(
                kyc_audit_jobs.update()
                .where(kyc_audit_jobs.c.session_id == session_id)
                .values(retry_count=kyc_audit_jobs.c.retry_count + 1, updated_at=now)
                .returning(kyc_audit_jobs.c.retry_count)
            )
            row = result.fetchone()
        return row[0] if row else 0

    # ── Queue / resume queries ────────────────────────────────────────────────

    async def find_incomplete_job(self, client_id: str) -> Optional[dict]:
        """
        Find any non-terminal job for this client (QUEUED, RUNNING, or
        mid-pipeline). Uses SELECT FOR UPDATE to prevent duplicate creation
        when two POST /audits calls race for the same client.
        """
        async with self.engine.begin() as conn:
            result = await conn.execute(
                sa.select(kyc_audit_jobs)
                .where(
                    sa.and_(
                        kyc_audit_jobs.c.client_id == client_id,
                        kyc_audit_jobs.c.status.notin_(["DONE", "FAILED"]),
                    )
                )
                .order_by(kyc_audit_jobs.c.created_at.desc())
                .limit(1)
                .with_for_update()
            )
            row = result.mappings().fetchone()
        return dict(row) if row else None

    async def get_job_by_session(self, session_id: str) -> Optional[dict]:
        async with self.engine.connect() as conn:
            result = await conn.execute(
                sa.select(kyc_audit_jobs)
                .where(kyc_audit_jobs.c.session_id == session_id)
            )
            row = result.mappings().fetchone()
        return dict(row) if row else None

    # ── Audit log ─────────────────────────────────────────────────────────────

    async def log_event(
        self,
        client_id:  str,
        session_id: str,
        event_type: str,
        agent_name: Optional[str] = None,
        details:    Optional[dict] = None,
    ) -> None:
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        async with self.engine.begin() as conn:
            await conn.execute(
                kyc_audit_log.insert().values(
                    client_id=client_id,
                    session_id=session_id,
                    event_type=event_type,
                    agent_name=agent_name,
                    details=details or {},
                    logged_at=now,
                )
            )
        logger.debug(f"Audit log: [{client_id}] {event_type}")
