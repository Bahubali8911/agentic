"""
API Schemas — Pydantic request/response DTOs.
FastAPI uses these for validation, serialisation, and OpenAPI docs generation.
In Java terms: these are your DTOs.
"""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class ClientProfile(BaseModel):
    client_id:            str
    full_name:            str
    client_type:          str          # INDIVIDUAL | CORPORATE
    email:                Optional[str] = None
    phone:                Optional[str] = None
    nationality:          Optional[str] = None
    date_of_birth:        Optional[str] = None
    company_name:         Optional[str] = None
    registration_number:  Optional[str] = None
    relationship_manager: Optional[str] = None
    risk_rating:          Optional[str] = None
    onboarding_date:      Optional[datetime] = None
    kyc_expiry_date:      Optional[datetime] = None
    created_at:           datetime
    updated_at:           datetime

    class Config:
        from_attributes = True


class AuditTriggerRequest(BaseModel):
    client_id: str = Field(
        ...,
        description="Client identifier. Must exist in the clients table.",
        example="CLI123456",
    )
    force_new: bool = Field(
        default=False,
        description=(
            "If true, abandons any in-progress audit and starts fresh. "
            "Use when a job is stuck. Default: false (resume if possible)."
        ),
    )


class AuditTriggerResponse(BaseModel):
    job_id:     int
    session_id: str
    client_id:  str
    status:     str    # QUEUED | RESUMED
    message:    str


class AuditJobSummary(BaseModel):
    id:                  int
    client_id:           str
    session_id:          str
    status:              str
    kyc_overall_status:  Optional[str] = None
    total_documents:     Optional[int] = None
    gcs_report_uri:      Optional[str] = None
    gcs_signed_url:      Optional[str] = None    # NEW: short-TTL HTTPS download URL
    error_message:       Optional[str] = None
    retry_count:         int
    docai_request_count: Optional[int] = None    # NEW: cost tracking
    created_at:          datetime
    updated_at:          datetime

    class Config:
        from_attributes = True


class AuditLogEntry(BaseModel):
    id:          int
    event_type:  str
    agent_name:  Optional[str] = None
    details:     Optional[dict] = None
    logged_at:   datetime

    class Config:
        from_attributes = True


class AuditDetailResponse(BaseModel):
    job:       AuditJobSummary
    client:    Optional[ClientProfile] = None
    audit_log: list[AuditLogEntry]


class AuditListResponse(BaseModel):
    client_id: str
    total:     int
    audits:    list[AuditJobSummary]


class HealthResponse(BaseModel):
    status:        str    # ok | degraded
    database:      str    # connected | unreachable
    worker_status: str    # running | stopped (set by worker loop)
    version:       str
