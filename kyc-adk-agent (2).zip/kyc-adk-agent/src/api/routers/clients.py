"""
Clients Router
===============
Endpoints for reading client profiles from the `clients` table.

GET /clients/{client_id}  — fetch a single client profile
GET /clients              — list all clients (paginated)

These endpoints are read-only. Client profiles are managed by the
upstream CRM system and written to this DB via a separate ETL process
or directly by the onboarding team. The KYC service never creates
or modifies client records.
"""

import logging
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from api.client_repository import ClientRepository
from api.dependencies import get_engine
from api.schemas import ClientProfile
from sqlalchemy.ext.asyncio import AsyncEngine

logger = logging.getLogger(__name__)
router = APIRouter()


def _get_client_repo(engine: Annotated[AsyncEngine, Depends(get_engine)]) -> ClientRepository:
    return ClientRepository(engine)


@router.get("/{client_id}", response_model=ClientProfile)
async def get_client(
    client_id: str,
    repo: Annotated[ClientRepository, Depends(_get_client_repo)],
) -> ClientProfile:
    """
    Fetch full client profile by client_id.

    Returns all stored client details including type (INDIVIDUAL/CORPORATE),
    contact info, relationship manager, risk rating, and KYC expiry date.

    Raises 404 if the client_id does not exist in the database.
    """
    client = await repo.get_by_client_id(client_id)
    if not client:
        raise HTTPException(
            status_code=404,
            detail=f"Client '{client_id}' not found. "
                   f"Ensure the client exists in the clients table before triggering an audit.",
        )
    return ClientProfile(**client)


@router.get("", response_model=list[ClientProfile])
async def list_clients(
    repo: Annotated[ClientRepository, Depends(_get_client_repo)],
    limit:  int = Query(default=50, ge=1, le=500, description="Max results per page"),
    offset: int = Query(default=0,  ge=0,          description="Rows to skip (pagination)"),
) -> list[ClientProfile]:
    """
    List all clients with pagination.

    Use `limit` and `offset` for pagination:
      GET /clients?limit=50&offset=0    ← first page
      GET /clients?limit=50&offset=50   ← second page
    """
    clients = await repo.list_all(limit=limit, offset=offset)
    return [ClientProfile(**c) for c in clients]
