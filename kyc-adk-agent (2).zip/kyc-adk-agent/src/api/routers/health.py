"""
Health Router — GET /health
============================
Used by K8s readiness/liveness probes, load balancers, and monitoring.
Returns database connectivity and worker loop status.
"""

from fastapi import APIRouter, Request
from sqlalchemy import text

from api.schemas import HealthResponse

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
async def health_check(request: Request) -> HealthResponse:
    """
    Service health check.

    Returns:
      status:        "ok" | "degraded"
      database:      "connected" | "unreachable"
      worker_status: "running" | "stopped" (worker loop inside this pod)
      version:       API version string
    """
    db_status = "unreachable"
    try:
        async with request.app.state.engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        db_status = "connected"
    except Exception:
        pass

    # Worker status is stored on app.state by server.py when it starts the loop
    worker_status = getattr(request.app.state, "worker_running", False)

    overall = "ok" if db_status == "connected" else "degraded"

    return HealthResponse(
        status=overall,
        database=db_status,
        worker_status="running" if worker_status else "stopped",
        version="1.0.0",
    )
