"""
Audits Router
==============
POST /audits                     — enqueue a KYC audit, return 202 immediately
GET  /audits/{client_id}         — list all audit jobs for a client
GET  /audits/{client_id}/latest  — full detail of most recent audit

DB-queue model (replaces BackgroundTasks)
------------------------------------------
POST /audits writes a QUEUED job row and returns 202 immediately.
The worker loop (worker.py) polls the DB and claims QUEUED rows with
SELECT FOR UPDATE SKIP LOCKED — safe for parallel workers, survives pod restarts.

Callers poll GET /audits/{client_id}/latest until status is DONE or FAILED.
When DONE, gcs_signed_url contains a 15-minute HTTPS download link for the
audit report — no GCP credentials needed by the caller.
"""

import logging
from datetime import datetime, timezone
from typing import Annotated

import sqlalchemy as sa
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncEngine

from api.client_repository import ClientRepository
from api.dependencies import get_engine, get_job_manager, get_session_service
from api.schemas import (
    AuditDetailResponse,
    AuditJobSummary,
    AuditListResponse,
    AuditLogEntry,
    AuditTriggerRequest,
    AuditTriggerResponse,
    ClientProfile,
)
from config.settings import settings
from db_init import kyc_audit_jobs, kyc_audit_log
from job_manager import KycJobManager

logger = logging.getLogger(__name__)
router = APIRouter()
APP_NAME = "KYCAuditor"


def _get_client_repo(engine: Annotated[AsyncEngine, Depends(get_engine)]) -> ClientRepository:
    return ClientRepository(engine)


# ══════════════════════════════════════════════════════════════════════════════
# POST /audits — Enqueue an audit
# ══════════════════════════════════════════════════════════════════════════════

@router.post("", response_model=AuditTriggerResponse, status_code=202)
async def trigger_audit(
    body:        AuditTriggerRequest,
    engine:      Annotated[AsyncEngine,     Depends(get_engine)],
    svc:         Annotated[object,           Depends(get_session_service)],
    job_manager: Annotated[KycJobManager,    Depends(get_job_manager)],
    client_repo: Annotated[ClientRepository, Depends(_get_client_repo)],
) -> AuditTriggerResponse:
    """
    Enqueue a KYC audit for a client.

    Returns HTTP 202 immediately. The worker picks up the job from the DB queue.
    Poll GET /audits/{client_id}/latest to check progress.

    force_new=true abandons any in-progress job and starts fresh.
    Default (false) resumes an existing job if one is in progress.

    Raises:
      404 — client_id not found in clients table
    """
    client_id = body.client_id

    # 1. Validate client exists, fetch full profile
    client_data = await client_repo.get_by_client_id(client_id)
    if not client_data:
        raise HTTPException(
            status_code=404,
            detail=f"Client '{client_id}' not found. "
                   f"Register the client before triggering an audit.",
        )

    # 2. force_new: abandon any in-progress job
    if body.force_new:
        existing = await job_manager.find_incomplete_job(client_id)
        if existing:
            await job_manager.update_status(
                existing["session_id"], "FAILED",
                error_message="Abandoned by force_new=true",
            )
            await job_manager.log_event(
                client_id, existing["session_id"],
                "ABANDONED", "API", {"reason": "force_new=true"},
            )

    # 3. Resume existing or create fresh session
    existing_job = await job_manager.find_incomplete_job(client_id)
    is_resume    = False

    if existing_job:
        session_id  = existing_job["session_id"]
        retry_count = await job_manager.increment_retry(session_id)
        if retry_count <= settings.MAX_JOB_RETRIES:
            existing_session = await svc.get_session(
                app_name=APP_NAME, user_id="system", session_id=session_id
            )
            if existing_session:
                is_resume = True
                # Re-queue so worker picks it up again
                await job_manager.update_status(session_id, "QUEUED")
                logger.info(f"Re-queued existing job for resume | client={client_id}")
        if not is_resume:
            await job_manager.update_status(
                session_id, "FAILED",
                error_message="Session lost or max retries exceeded",
            )

    if not is_resume:
        # Build initial session state from client profile
        initial_state = {
            "client_id":            client_data["client_id"],
            "client_type":          client_data["client_type"],
            "client_full_name":     client_data["full_name"],
            "client_email":         client_data.get("email"),
            "client_phone":         client_data.get("phone"),
            "client_nationality":   client_data.get("nationality"),
            "client_risk_rating":   client_data.get("risk_rating"),
            "relationship_manager": client_data.get("relationship_manager"),
            "company_name":         client_data.get("company_name"),
            "registration_number":  client_data.get("registration_number"),
        }
        new_session = await svc.create_session(
            app_name=APP_NAME, user_id="system", state=initial_state,
        )
        session_id = new_session.id
        await job_manager.create_job(client_id, session_id)
        logger.info(f"New job queued | client={client_id} | session={session_id[:12]}...")

    job_row = await job_manager.get_job_by_session(session_id)
    job_id  = job_row["id"] if job_row else -1

    return AuditTriggerResponse(
        job_id=job_id,
        session_id=session_id,
        client_id=client_id,
        status="RESUMED" if is_resume else "QUEUED",
        message=(
            f"Audit {'re-queued for resume' if is_resume else 'queued'} "
            f"for client {client_id}. "
            f"Poll GET /audits/{client_id}/latest for status updates."
        ),
    )


# ══════════════════════════════════════════════════════════════════════════════
# GET /audits/{client_id} — List all audits
# ══════════════════════════════════════════════════════════════════════════════

@router.get("/{client_id}", response_model=AuditListResponse)
async def list_audits(
    client_id:   str,
    engine:      Annotated[AsyncEngine,     Depends(get_engine)],
    client_repo: Annotated[ClientRepository, Depends(_get_client_repo)],
) -> AuditListResponse:
    """List all audit jobs for a client, newest first."""
    if not await client_repo.exists(client_id):
        raise HTTPException(status_code=404, detail=f"Client '{client_id}' not found.")

    async with engine.connect() as conn:
        result = await conn.execute(
            sa.select(kyc_audit_jobs)
            .where(kyc_audit_jobs.c.client_id == client_id)
            .order_by(kyc_audit_jobs.c.created_at.desc())
        )
        rows = result.mappings().fetchall()

    return AuditListResponse(
        client_id=client_id,
        total=len(rows),
        audits=[AuditJobSummary(**_fix_dt(dict(r))) for r in rows],
    )


# ══════════════════════════════════════════════════════════════════════════════
# GET /audits/{client_id}/latest — Full detail of most recent audit
# ══════════════════════════════════════════════════════════════════════════════

@router.get("/{client_id}/latest", response_model=AuditDetailResponse)
async def get_latest_audit(
    client_id:   str,
    engine:      Annotated[AsyncEngine,     Depends(get_engine)],
    client_repo: Annotated[ClientRepository, Depends(_get_client_repo)],
) -> AuditDetailResponse:
    """
    Full detail of the most recent audit for a client.

    Includes job status, client profile snapshot, and full compliance event log.
    When status=DONE, gcs_signed_url contains a 15-minute HTTPS download link
    for the audit report. No GCP credentials required by the caller.

    Poll every 15-30 seconds until status is DONE or FAILED.
    """
    client_data = await client_repo.get_by_client_id(client_id)
    if not client_data:
        raise HTTPException(status_code=404, detail=f"Client '{client_id}' not found.")

    async with engine.connect() as conn:
        job_result = await conn.execute(
            sa.select(kyc_audit_jobs)
            .where(kyc_audit_jobs.c.client_id == client_id)
            .order_by(kyc_audit_jobs.c.created_at.desc())
            .limit(1)
        )
        job_row = job_result.mappings().fetchone()

    if not job_row:
        raise HTTPException(
            status_code=404,
            detail=f"No audit found for '{client_id}'. "
                   f"Trigger one via POST /audits.",
        )

    job = AuditJobSummary(**_fix_dt(dict(job_row)))

    async with engine.connect() as conn:
        log_result = await conn.execute(
            sa.select(kyc_audit_log)
            .where(kyc_audit_log.c.session_id == job.session_id)
            .order_by(kyc_audit_log.c.logged_at.asc())
        )
        log_rows = log_result.mappings().fetchall()

    return AuditDetailResponse(
        job=job,
        client=ClientProfile(**client_data),
        audit_log=[AuditLogEntry(**_fix_dt(dict(r))) for r in log_rows],
    )


# ── Utility ───────────────────────────────────────────────────────────────────

def _fix_dt(row: dict) -> dict:
    """Add UTC tzinfo to naive datetimes returned by SQLAlchemy from PostgreSQL."""
    for k, v in row.items():
        if isinstance(v, datetime) and v.tzinfo is None:
            row[k] = v.replace(tzinfo=timezone.utc)
    return row
