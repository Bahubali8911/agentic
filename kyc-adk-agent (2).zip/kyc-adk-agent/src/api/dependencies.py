"""
FastAPI Dependencies
=====================
Provides shared resources (engine, session_service, job_manager) to routers
via FastAPI's Depends() mechanism.

In Java/Spring terms: these are equivalent to @Autowired injections,
but explicit and testable — you can override them in tests by overriding
app.dependency_overrides[get_engine] = lambda: test_engine.

All resources are created once at startup (lifespan in app.py) and stored
on app.state. These functions simply extract them from app.state so routers
don't need to know where they come from.
"""

from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncEngine

from job_manager import KycJobManager


def get_engine(request: Request) -> AsyncEngine:
    """Return the shared async DB engine created at startup."""
    return request.app.state.engine


def get_session_service(request: Request):
    """Return the shared ADK DatabaseSessionService created at startup."""
    return request.app.state.session_service


def get_job_manager(request: Request) -> KycJobManager:
    """Return the shared KycJobManager created at startup."""
    return request.app.state.job_manager
