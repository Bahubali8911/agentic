"""
KYC Auditor — FastAPI Application
===================================
REST service exposing the KYC pipeline over HTTP.

Database is always real (SQLite locally, PostgreSQL in production).
External APIs (DocAI, GCS, Document API) are mocked when MOCK_MODE=true.

Startup order:
  1. connect_and_verify() — SQLite: auto-creates tables.
                          — PostgreSQL: verifies tables exist (migrate.py must
                            have been run beforehand).
  2. create_session_service() — ADK session service, same DB, sync driver.
  3. KycJobManager — thin async CRUD layer over our job tables.
  4. App ready — worker loop starts, HTTP requests accepted.
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api.routers import audits, clients, health
from db_init import connect_and_verify
from job_manager import KycJobManager
from session_factory import create_session_service
from config.settings import settings

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("=" * 55)
    logger.info("  KYC AUDITOR REST SERVICE — STARTING UP")
    logger.info(f"  DB: {settings.DATABASE_URL.split('///')[0] + '://...'}")
    logger.info("=" * 55)

    # Step 1: DB — SQLite auto-creates tables; PostgreSQL verifies they exist
    logger.info("Step 1: Connecting to database...")
    engine = await connect_and_verify(max_retries=10, retry_delay_seconds=3.0)
    app.state.engine = engine
    logger.info("Step 1: Database ready ✅")

    # Step 2: ADK session service (sync driver, same DB)
    logger.info("Step 2: Creating ADK session service...")
    session_service = create_session_service()
    app.state.session_service = session_service
    logger.info("Step 2: Session service ready ✅")

    # Step 3: Job manager
    app.state.job_manager     = KycJobManager(engine)
    app.state.worker_running  = False   # set True by server.py when worker starts
    logger.info("Step 3: KycJobManager ready ✅")

    logger.info("KYC Auditor ready — accepting requests")

    yield

    logger.info("Shutting down...")
    await engine.dispose()
    logger.info("Shutdown complete.")


def create_app() -> FastAPI:
    app = FastAPI(
        title="KYC Auditor API",
        description=(
            "REST service for triggering and monitoring KYC document audits. "
            "Accepts a client_id, fetches the client profile from the database, "
            "and runs a four-agent ADK pipeline to classify documents and "
            "produce a structured compliance report.\n\n"
            "Database: SQLite (local) or PostgreSQL (production).\n"
            "Set MOCK_MODE=true to mock external APIs (DocAI, GCS, Document API)."
        ),
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],   # restrict in production
        allow_methods=["GET", "POST"],
        allow_headers=["*"],
    )

    app.include_router(health.router,  tags=["Health"])
    app.include_router(clients.router, prefix="/clients", tags=["Clients"])
    app.include_router(audits.router,  prefix="/audits",  tags=["Audits"])

    return app


app = create_app()
