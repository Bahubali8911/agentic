"""
Client Repository
==================
All database queries against the `clients` table live here.
No SQL anywhere else in the API layer.

The clients table stores the full profile of every KYC client.
The pipeline reads client_type from here to load the correct checklist
(INDIVIDUAL vs CORPORATE document requirements).

This is the data-access layer — equivalent to a Spring @Repository.
"""

import logging
from datetime import datetime, timezone
from typing import Optional

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncEngine
from sqlalchemy import text

from db_init import metadata

logger = logging.getLogger(__name__)

# ── Table definition ──────────────────────────────────────────────────────────
# Added to the shared metadata so migrate.py picks it up automatically.

clients_table = sa.Table(
    "clients",
    metadata,
    sa.Column("id",                   sa.Integer,     primary_key=True, autoincrement=True),
    sa.Column("client_id",            sa.String(255), nullable=False, unique=True, index=True),
    sa.Column("full_name",            sa.String(512), nullable=False),
    sa.Column("client_type",          sa.String(50),  nullable=False,
              comment="INDIVIDUAL | CORPORATE"),
    sa.Column("email",                sa.String(255), nullable=True),
    sa.Column("phone",                sa.String(50),  nullable=True),
    sa.Column("nationality",          sa.String(100), nullable=True),
    sa.Column("date_of_birth",        sa.String(20),  nullable=True,   comment="YYYY-MM-DD"),
    sa.Column("company_name",         sa.String(512), nullable=True,   comment="CORPORATE only"),
    sa.Column("registration_number",  sa.String(255), nullable=True,   comment="CORPORATE only"),
    sa.Column("relationship_manager", sa.String(255), nullable=True),
    sa.Column("risk_rating",          sa.String(20),  nullable=True,
              comment="LOW | MEDIUM | HIGH"),
    sa.Column("onboarding_date",      sa.DateTime,    nullable=True),
    sa.Column("kyc_expiry_date",      sa.DateTime,    nullable=True),
    sa.Column("created_at",           sa.DateTime,    nullable=False),
    sa.Column("updated_at",           sa.DateTime,    nullable=False),
)


class ClientRepository:
    """
    Data access layer for the clients table.
    All methods are async — uses the shared AsyncEngine.
    """

    def __init__(self, engine: AsyncEngine):
        self.engine = engine

    async def get_by_client_id(self, client_id: str) -> Optional[dict]:
        """
        Fetch a client profile by their client_id.

        Returns:
            Client row as a dict, or None if not found.
        """
        async with self.engine.connect() as conn:
            result = await conn.execute(
                sa.select(clients_table).where(
                    clients_table.c.client_id == client_id
                )
            )
            row = result.mappings().fetchone()
        if row:
            logger.info(f"Client found: {client_id} ({row['client_type']})")
        else:
            logger.warning(f"Client not found: {client_id}")
        return dict(row) if row else None

    async def list_all(self, limit: int = 100, offset: int = 0) -> list[dict]:
        """
        List all clients with pagination.

        Args:
            limit:  Max rows to return (default 100).
            offset: Rows to skip (for pagination).

        Returns:
            List of client dicts ordered by client_id.
        """
        async with self.engine.connect() as conn:
            result = await conn.execute(
                sa.select(clients_table)
                .order_by(clients_table.c.client_id)
                .limit(limit)
                .offset(offset)
            )
            rows = result.mappings().fetchall()
        return [dict(r) for r in rows]

    async def exists(self, client_id: str) -> bool:
        """
        Check if a client exists without fetching the full row.
        Used for validation before triggering an audit.
        """
        async with self.engine.connect() as conn:
            result = await conn.execute(
                sa.select(sa.func.count())
                .select_from(clients_table)
                .where(clients_table.c.client_id == client_id)
            )
            count = result.scalar()
        return count > 0
