"""
KYC Auditor — Local Dev Runner (MOCK_MODE)
==========================================
Runs the complete pipeline end-to-end with external calls mocked:
  ✅ Document API  → mock_document_api.py  (fake document tokens + PDF bytes)
  ✅ DocAI API     → mock_docai.py          (filename-based classification)
  ✅ GCS uploads   → mock_gcs.py            (writes to /tmp/mock-gcs/)
  ✅ Database      → SQLite at ./kyc_local.db  (REAL persistence, no mock)
  🔴 LLM (Gemini) → REAL                   (requires GOOGLE_API_KEY)

The database is real SQLite — sessions, job state, and audit log are all
persisted to kyc_local.db. Re-run with the same client_id to test resume
behaviour. Delete kyc_local.db to reset everything.

Prerequisites:
  pip install google-adk sqlalchemy aiosqlite pydantic-settings
  export GOOGLE_API_KEY=your-gemini-key
  # No other env vars needed — all have sensible defaults for local dev

Usage:
  python main_mock.py                  # defaults to client CLI123456
  python main_mock.py CLI123456        # individual client
  python main_mock.py CORP789012       # corporate client (10 docs)

To inspect the local DB after a run:
  sqlite3 kyc_local.db "SELECT client_id, status, kyc_overall_status FROM kyc_audit_jobs;"
  sqlite3 kyc_local.db "SELECT event_type, agent_name, logged_at FROM kyc_audit_log;"
"""

import asyncio
import logging
import os
import sys
from pathlib import Path

# Add src/ to path so all internal modules resolve without a src. prefix
sys.path.insert(0, str(Path(__file__).parent / "src"))

# Force mock mode before any other imports touch settings
os.environ.setdefault("MOCK_MODE", "true")

from google.adk.runners import Runner
from google.genai.types import Content, Part

from db_init import connect_and_verify
from session_factory import create_session_service
from job_manager import KycJobManager
from config.settings import settings

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
logger = logging.getLogger(__name__)

APP_NAME = "KYCAuditor"


async def run_mock_audit(client_id: str) -> dict:
    """Run the full KYC pipeline with mocked external APIs and real SQLite DB."""

    logger.info("=" * 60)
    logger.info("  KYC AUDITOR — LOCAL DEV MODE")
    logger.info(f"  Client:   {client_id}")
    logger.info(f"  Database: {settings.DATABASE_URL}")
    logger.info("=" * 60)

    # ── Init DB (SQLite auto-creates all tables) ──────────────────────────────
    engine = await connect_and_verify()

    # ── ADK session service (SQLite backend via session_factory) ──────────────
    session_service = create_session_service()
    job_manager     = KycJobManager(engine)

    # ── Resolve session (resume existing or create new) ───────────────────────
    session_id = await _resolve_session(client_id, job_manager, session_service)

    # ── Build pipeline with mock external tools ───────────────────────────────
    kyc_pipeline = _build_pipeline()

    logger.info(f"Running pipeline | client={client_id} | session={session_id[:12]}...")
    await job_manager.log_event(client_id, session_id, "PIPELINE_STARTED")
    await job_manager.update_status(session_id, "RUNNING")

    runner = Runner(
        agent=kyc_pipeline,
        app_name=APP_NAME,
        session_service=session_service,
    )

    final_state = {}
    try:
        STATUS_MAP = {
            "DocumentFetcherAgent":  "FETCH_COMPLETE",
            "DocClassifierAgent":    "CLASSIFY_COMPLETE",
            "ChecklistMatcherAgent": "MATCH_COMPLETE",
            "StorageAgent":          "DONE",
        }

        async for event in runner.run_async(
            user_id="system",
            session_id=session_id,
            new_message=Content(
                role="user",
                parts=[Part(text=f"Run full KYC audit for client {client_id}.")],
            ),
        ):
            author = getattr(event, "author", None)
            if author in STATUS_MAP and event.is_final_response():
                await job_manager.update_status(session_id, STATUS_MAP[author])
                await job_manager.log_event(client_id, session_id, STATUS_MAP[author], author)

        final_session = await session_service.get_session(
            app_name=APP_NAME, user_id="system", session_id=session_id
        )
        final_state = final_session.state if final_session else {}

        if final_state.get("pipeline_aborted"):
            reason = final_state.get("abort_reason", "Unknown")
            await job_manager.update_status(session_id, "FAILED", error_message=reason)
            logger.error(f"Pipeline aborted: {reason}")
        else:
            report = final_state.get("audit_report", {})
            await job_manager.update_status(
                session_id, "DONE",
                kyc_overall_status=report.get("overall_kyc_status"),
                total_documents=report.get("summary", {}).get("total_documents_received"),
            )

    except Exception as e:
        logger.error(f"Pipeline error: {e}", exc_info=True)
        await job_manager.update_status(session_id, "FAILED", error_message=str(e))
        raise

    _print_summary(final_state)
    await engine.dispose()
    return final_state


def _build_pipeline():
    """Build the pipeline injecting mock external tools. LLM is always real."""
    from google.adk.agents import SequentialAgent, LlmAgent
    from mocks.mock_document_api import search_documents, download_document
    from mocks.mock_docai import submit_classification_job, poll_classification_result
    from mocks.mock_gcs import generate_document_name, upload_to_gcs
    from tools.checklist_tools import load_kyc_checklist, generate_audit_report
    from agents.document_fetcher import document_fetcher_agent
    from agents.doc_classifier import doc_classifier_agent
    from agents.checklist_matcher import checklist_matcher_agent
    from agents.storage_agent import storage_agent

    return SequentialAgent(
        name="KYCAuditorPipeline",
        description="KYC audit pipeline (local dev — mock external APIs)",
        sub_agents=[
            LlmAgent(
                name=document_fetcher_agent.name,
                model=document_fetcher_agent.model,
                description=document_fetcher_agent.description,
                instruction=document_fetcher_agent.instruction,
                tools=[search_documents, download_document],
            ),
            LlmAgent(
                name=doc_classifier_agent.name,
                model=doc_classifier_agent.model,
                description=doc_classifier_agent.description,
                instruction=doc_classifier_agent.instruction,
                tools=[submit_classification_job, poll_classification_result],
            ),
            LlmAgent(
                name=checklist_matcher_agent.name,
                model=checklist_matcher_agent.model,
                description=checklist_matcher_agent.description,
                instruction=checklist_matcher_agent.instruction,
                tools=[load_kyc_checklist, generate_audit_report],
            ),
            LlmAgent(
                name=storage_agent.name,
                model=storage_agent.model,
                description=storage_agent.description,
                instruction=storage_agent.instruction,
                tools=[generate_document_name, upload_to_gcs],
            ),
        ],
    )


async def _resolve_session(client_id: str, job_manager: KycJobManager, session_service) -> str:
    """Resume an existing incomplete session or create a fresh one."""
    existing_job = await job_manager.find_incomplete_job(client_id)
    if existing_job:
        session_id  = existing_job["session_id"]
        retry_count = await job_manager.increment_retry(session_id)
        if retry_count <= settings.MAX_JOB_RETRIES:
            existing_session = await session_service.get_session(
                app_name=APP_NAME, user_id="system", session_id=session_id
            )
            if existing_session:
                logger.info(f"♻️  Resuming | session={session_id[:12]}... | retry={retry_count}")
                return session_id
        await job_manager.update_status(session_id, "FAILED", error_message="Not resumable")

    new_session = await session_service.create_session(
        app_name=APP_NAME, user_id="system", state={"client_id": client_id}
    )
    session_id = new_session.id
    await job_manager.create_job(client_id, session_id)
    logger.info(f"🆕 New session | client={client_id} | session={session_id[:12]}...")
    return session_id


def _print_summary(state: dict) -> None:
    report  = state.get("audit_report", {})
    summary = report.get("summary", {})

    logger.info("")
    logger.info("━" * 60)
    logger.info("  RUN COMPLETE")
    logger.info(f"  KYC Status:          {report.get('overall_kyc_status', 'UNKNOWN')}")
    logger.info(f"  Docs received:       {summary.get('total_documents_received', 0)}")
    logger.info(f"  Matched:             {summary.get('matched', 0)}")
    logger.info(f"  Missing mandatory:   {summary.get('missing_mandatory', 0)}")
    logger.info(f"  Human review needed: {report.get('requires_human_review', False)}")
    logger.info(f"  GCS output:          /tmp/mock-gcs/{settings.GCS_BUCKET_NAME}/")
    logger.info(f"  SQLite DB:           ./kyc_local.db")
    logger.info(f"")
    logger.info(f"  Inspect DB:")
    logger.info(f'  sqlite3 kyc_local.db "SELECT client_id, status, kyc_overall_status FROM kyc_audit_jobs;"')
    logger.info("━" * 60)


if __name__ == "__main__":
    client_id = sys.argv[1] if len(sys.argv) > 1 else "CLI123456"
    asyncio.run(run_mock_audit(client_id))
