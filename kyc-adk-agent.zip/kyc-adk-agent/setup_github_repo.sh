#!/bin/bash
# ============================================================
# setup_github_repo.sh
# Run this from inside the kyc-adk-agent/ directory.
# Prerequisites: git, gh (GitHub CLI) installed and authenticated
#   brew install gh   (mac)
#   gh auth login
# ============================================================

set -e  # Exit on any error

REPO_NAME="kyc-adk-agent"
REPO_DESCRIPTION="KYC Auditor — Agentic AI pipeline built on Google ADK with Cloud SQL state persistence"
VISIBILITY="private"   # Change to "public" if desired

echo "=================================================="
echo " KYC ADK Agent — GitHub Repo Setup"
echo "=================================================="

# ── 1. Initialise local git repo ──────────────────────────
echo "→ Initialising git..."
git init
git checkout -b main

# ── 2. Create .gitignore ──────────────────────────────────
cat > .gitignore << 'EOF'
# Environment
.env
*.env

# Python
__pycache__/
*.pyc
*.pyo
*.pyd
.Python
*.egg-info/
dist/
build/
.venv/
venv/
env/

# IDE
.idea/
.vscode/
*.swp
*.swo

# Test artifacts
.pytest_cache/
.coverage
htmlcov/

# OS
.DS_Store
Thumbs.db
EOF

# ── 3. Initial commit ─────────────────────────────────────
echo "→ Creating initial commit..."
git add .
git commit -m "feat: initial KYC auditor agentic pipeline

- Multi-agent pipeline using Google ADK (SequentialAgent)
- Agents: DocumentFetcher, DocClassifier, ChecklistMatcher, StorageAgent
- Cloud SQL (PostgreSQL) state persistence via DatabaseSessionService
- Crash-safe resume logic with kyc_audit_jobs tracking table
- GCS document storage with standardised naming convention
- GKE deployment with Cloud SQL Auth Proxy sidecar"

# ── 4. Create GitHub repo and push ───────────────────────
echo "→ Creating GitHub repo: $REPO_NAME..."
gh repo create "$REPO_NAME" \
  --description "$REPO_DESCRIPTION" \
  --"$VISIBILITY" \
  --source=. \
  --remote=origin \
  --push

echo ""
echo "✅ Done! Repo created and pushed."
echo "   https://github.com/$(gh api user --jq .login)/$REPO_NAME"
