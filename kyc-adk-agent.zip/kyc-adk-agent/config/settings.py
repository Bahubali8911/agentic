"""
Application Settings
Loaded from environment variables or .env file.
"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):

    # ── Document Fetch API ────────────────────────────────────────────────────
    DOCUMENT_API_BASE_URL: str = "https://your-document-api.example.com/v1"
    DOCUMENT_API_KEY: str = ""

    # ── DocAI Wrapper API ─────────────────────────────────────────────────────
    DOCAI_API_BASE_URL: str = "https://your-docai-api.example.com/v1"
    DOCAI_API_KEY: str = ""

    # ── GCP ───────────────────────────────────────────────────────────────────
    GCP_PROJECT_ID: str = "your-gcp-project-id"
    GCS_BUCKET_NAME: str = "kyc-documents"

    # ── Gemini / ADK ──────────────────────────────────────────────────────────
    GOOGLE_API_KEY: str = ""
    GEMINI_MODEL_DEFAULT: str = "gemini-2.5-flash"
    GEMINI_MODEL_REASONING: str = "gemini-2.5-pro"

    # ── Cloud SQL (PostgreSQL via Cloud SQL Auth Proxy sidecar) ───────────────
    # asyncpg URL — used by our async engine in db_init.py
    # The sidecar listens on 127.0.0.1:5432 inside the pod
    DATABASE_URL: str = (
        "postgresql+asyncpg://kyc_user:password@127.0.0.1:5432/kyc_db"
    )
    # Note: session_factory.py swaps asyncpg → psycopg2 for the ADK service

    DB_POOL_SIZE: int = 5
    DB_MAX_OVERFLOW: int = 10
    DB_ECHO_SQL: bool = False          # Set True to log all SQL (dev only)

    # ── Pipeline behaviour ────────────────────────────────────────────────────
    CLASSIFICATION_CONFIDENCE_THRESHOLD: float = 0.7
    MAX_JOB_RETRIES: int = 3           # Give up after this many pod restarts

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
