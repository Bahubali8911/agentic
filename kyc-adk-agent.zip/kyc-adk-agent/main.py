"""
KYC Auditor — Main Entry Point
================================
Startup order is strictly enforced:

  STEP 1: Connect to Cloud SQL + verify connection  (db_init)
  STEP 2: Create all tables if not exist            (db_init)
  STEP 3: Verify all tables present                 (db_init)
  STEP 4: Create ADK DatabaseSessionService         (session_factory)
  STEP 5: Check for resumable in-progress job       (job_manager)
  STEP 6: Run the KYC pipeline                      (runner)

If the container is restarted mid-audit, Step 5 detects the incomplete
job and resumes from the last checkpoint using the saved session_id.

Usage:
  python main.py <client_id>
  python main.py CLI123456
  python main.py CORP789012
"""

import asyncio
import logging
import sys

from google.adk.runners import Runner
from google.genai.types import Content, Part

from agents.coordinator import kyc_pipeline
from config.settings import settings
from db_init import init_database
from session_factory import create_session_service
from job_manager import KycJobManager

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
logger = logging.getLogger(__name__)
APP_NAME = "KYCAuditor"


async def run_kyc_audit(client_id: str) -> dict:
    # ── STEP 1-3: DB init — tables MUST exist before anything else ────────────
    logger.info("STEP 1-3: Initializing database and verifying all tables...")
    async_engine = await init_database(max_retries=10, retry_delay_seconds=3.0)
    logger.info("All tables verified OK.")

    # ── STEP 4: ADK session service (safe now that tables exist) ─────────────
    logger.info("STEP 4: Creating ADK DatabaseSessionService...")
    session_service = create_session_service()
    job_manager = KycJobManager(async_engine)

    # ── STEP 5: Resume or start fresh ────────────────────────────────────────
    logger.info(f"STEP 5: Resolving session for client {client_id}...")
    session_id = await _resolve_session(client_id, job_manager, session_service)

    # ── STEP 6: Run the pipeline ──────────────────────────────────────────────
    logger.info(f"STEP 6: Running pipeline | client={client_id} | session={session_id}")
    await job_manager.log_event(client_id, session_id, "PIPELINE_STARTED", "KYCAuditorPipeline")

    runner = Runner(agent=kyc_pipeline, app_name=APP_NAME, session_service=session_service)
    initial_message = Content(
        role="user",
        parts=[Part(text=f"Run full KYC audit for client {client_id}.")],
    )

    final_state = {}
    try:
        async for event in runner.run_async(
            user_id="system", session_id=session_id, new_message=initial_message
        ):
            if hasattr(event, "author") and event.author:
                author = event.author
                if hasattr(event, "content") and event.content:
                    for part in event.content.parts:
                        if hasattr(part, "text") and part.text:
                            logger.info(f"[{author}] {part.text[:200]}")

                # Update job status after each agent completes
                status_map = {
                    "DocumentFetcherAgent": "FETCH_COMPLETE",
                    "DocClassifierAgent":   "CLASSIFY_COMPLETE",
                    "ChecklistMatcherAgent":"MATCH_COMPLETE",
                    "StorageAgent":         "DONE",
                }
                if event.author in status_map and event.is_final_response():
                    await job_manager.update_status(session_id, status_map[event.author])
                    await job_manager.log_event(client_id, session_id, status_map[event.author], event.author)

        final_session = await session_service.get_session(
            app_name=APP_NAME, user_id="system", session_id=session_id
        )
        final_state = final_session.state if final_session else {}

        report = final_state.get("audit_report", {})
        stored = final_state.get("stored_files", [])
        await job_manager.update_status(
            session_id, "DONE",
            kyc_overall_status=report.get("overall_kyc_status"),
            total_documents=report.get("summary", {}).get("total_documents_received"),
            gcs_report_uri=next(
                (f["gcs_uri"] for f in stored if "AUDIT_REPORT" in f.get("filename", "")), None
            ),
        )
        await job_manager.log_event(client_id, session_id, "PIPELINE_COMPLETE", "KYCAuditorPipeline",
                                    {"kyc_status": report.get("overall_kyc_status")})

    except Exception as e:
        logger.error(f"Pipeline failed: {e}", exc_info=True)
        await job_manager.update_status(session_id, "FAILED", error_message=str(e))
        await job_manager.log_event(client_id, session_id, "FAILED", "KYCAuditorPipeline", {"error": str(e)})
        raise

    _print_summary(final_state)
    return final_state


async def _resolve_session(client_id, job_manager, session_service) -> str:
    existing_job = await job_manager.find_incomplete_job(client_id)
    if existing_job:
        session_id = existing_job["session_id"]
        retry_count = await job_manager.increment_retry(session_id)
        if retry_count <= settings.MAX_JOB_RETRIES:
            existing_session = await session_service.get_session(
                app_name=APP_NAME, user_id="system", session_id=session_id
            )
            if existing_session:
                logger.info(f"RESUMING job | session={session_id} | last_status={existing_job['status']} | retry={retry_count}")
                return session_id
        logger.warning(f"Job {session_id} not resumable. Starting fresh.")
        await job_manager.update_status(session_id, "FAILED", error_message="Exceeded max retries or session lost")

    new_session = await session_service.create_session(
        app_name=APP_NAME, user_id="system", state={"client_id": client_id}
    )
    session_id = new_session.id
    await job_manager.create_job(client_id, session_id)
    logger.info(f"NEW job | client={client_id} | session={session_id}")
    return session_id


def _print_summary(state: dict) -> None:
    report = state.get("audit_report", {})
    summary = report.get("summary", {})
    logger.info("=" * 60)
    logger.info(f"  KYC Status:          {report.get('overall_kyc_status', 'UNKNOWN')}")
    logger.info(f"  Report ID:           {report.get('report_id', 'N/A')}")
    logger.info(f"  Matched:             {summary.get('matched', 0)}")
    logger.info(f"  Missing (mandatory): {summary.get('missing_mandatory', 0)}")
    logger.info(f"  Human Review:        {report.get('requires_human_review', False)}")
    logger.info(f"  Files in GCS:        {len(state.get('stored_files', []))}")
    logger.info("=" * 60)


if __name__ == "__main__":
    client_id = sys.argv[1] if len(sys.argv) > 1 else "CLI123456"
    asyncio.run(run_kyc_audit(client_id))
