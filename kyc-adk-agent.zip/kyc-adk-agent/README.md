# KYC Auditor — Agentic AI Pipeline

An end-to-end KYC document audit pipeline built on **Google Agent Development Kit (ADK)**.

---

## Architecture

```
User / System
     │
     ▼
┌────────────────────────────────────────────────────────┐
│               KYCAuditorPipeline (SequentialAgent)     │
│                                                        │
│  ┌─────────────────────┐                               │
│  │ 1. DocumentFetcher  │  → REST API (search + download)│
│  │    LlmAgent         │    Up to ~20 docs, one by one  │
│  └──────────┬──────────┘                               │
│             │ session state: fetched_documents          │
│  ┌──────────▼──────────┐                               │
│  │ 2. DocClassifier    │  → Custom DocAI wrapper API    │
│  │    LlmAgent         │    One PDF at a time           │
│  └──────────┬──────────┘                               │
│             │ session state: classified_documents       │
│  ┌──────────▼──────────┐                               │
│  │ 3. ChecklistMatcher │  → KYC checklist config        │
│  │    LlmAgent         │    Produces audit report       │
│  └──────────┬──────────┘                               │
│             │ session state: audit_report               │
│  ┌──────────▼──────────┐                               │
│  │ 4. StorageAgent     │  → Google Cloud Storage (GCS)  │
│  │    LlmAgent         │    Renamed + uploaded           │
│  └─────────────────────┘                               │
└────────────────────────────────────────────────────────┘
```

## Agent Breakdown

| Agent | Model | Role |
|---|---|---|
| `DocumentFetcherAgent` | gemini-2.5-flash | Calls search API → gets tokens → downloads each doc |
| `DocClassifierAgent` | gemini-2.5-flash | Sends each PDF to DocAI → gets doc type + confidence |
| `ChecklistMatcherAgent` | gemini-2.5-pro | Matches docs to KYC checklist → generates audit report |
| `StorageAgent` | gemini-2.5-flash | Renames docs → uploads to GCS |

## Session State Flow

```
client_id                          (input)
    └─► fetched_documents          (after Agent 1)
            └─► classified_documents  (after Agent 2)
                    └─► audit_report     (after Agent 3)
                            └─► stored_files  (after Agent 4)
```

## GCS Naming Convention

```
gs://{bucket}/{client_id}/{CLIENT_ID}_{DOCUMENT_TYPE}_{YYYYMMDD}_{INDEX:03d}.pdf

Examples:
  gs://kyc-documents/CLI123/CLI123_PASSPORT_20250226_001.pdf
  gs://kyc-documents/CLI123/CLI123_PROOF_OF_ADDRESS_20250226_002.pdf
  gs://kyc-documents/CLI123/CLI123_KYC_AUDIT_REPORT_20250226.json
```

## KYC Checklist

The checklist is config-driven in `config/kyc_checklist.py`. Two profiles:
- **INDIVIDUAL** — Passport/ID, Proof of Address, Bank Statement, Tax Docs
- **CORPORATE** — Incorporation cert, Directors register, Shareholders, Financials, UBO passports

Client type is determined by `client_id` prefix (`CORP*` = Corporate, else Individual). Extend `_lookup_client_type()` to query your CRM.

## Document Status in Audit Report

| Status | Meaning |
|---|---|
| `PRESENT` | Document found, confidence ≥ 0.7 |
| `LOW_CONFIDENCE` | Found but confidence < 0.7 — needs human review |
| `MISSING` | Required document not found |
| `DUPLICATE` | More than one document of same type |
| `UNEXPECTED` | Document received but not on checklist |

Overall KYC status = **PASS** only if all mandatory documents are `PRESENT`.

---

## Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure environment
cp .env.example .env
# Edit .env with your API keys and GCP config

# 3. Authenticate with GCP (for GCS)
gcloud auth application-default login

# 4. Run the pipeline
python main.py CLI123456

# Or launch the ADK dev UI
adk web
```

## Project Structure

```
kyc-adk-agent/
├── main.py                      # Pipeline runner / entry point
├── requirements.txt
├── .env.example
├── agents/
│   ├── coordinator.py           # Root SequentialAgent
│   ├── document_fetcher.py      # Agent 1: Fetch docs
│   ├── doc_classifier.py        # Agent 2: Classify via DocAI
│   ├── checklist_matcher.py     # Agent 3: Match + report
│   └── storage_agent.py         # Agent 4: Rename + GCS upload
├── tools/
│   ├── document_api_tools.py    # search_documents, download_document
│   ├── docai_tools.py           # classify_document
│   ├── checklist_tools.py       # load_kyc_checklist, generate_audit_report
│   └── gcs_tools.py             # generate_document_name, upload_to_gcs
└── config/
    ├── settings.py              # Pydantic settings (env vars)
    └── kyc_checklist.py         # KYC document requirements per client type
```
