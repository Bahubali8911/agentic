"""
Session Service Factory
=======================
Creates and returns the ADK DatabaseSessionService configured for Cloud SQL.

Key decisions made here:
  1. Uses psycopg2 (sync) driver — ADK's DatabaseSessionService internally
     uses SQLAlchemy sync APIs despite async method signatures (issue #1005).
     asyncpg would not work correctly here.

  2. The timezone-aware datetime bug (issue #4366) is worked around by using
     TIMESTAMP WITHOUT TIME ZONE (PostgreSQL default) and stripping tzinfo
     before writes. The "UTC" server_settings in db_init.py ensures the DB
     stores and returns UTC.

  3. A single shared instance is created at startup and reused across the
     entire container lifetime. This is safe — DatabaseSessionService is
     thread-safe via SQLAlchemy connection pooling.
"""

import logging
from functools import lru_cache

from google.adk.sessions import DatabaseSessionService
from config.settings import settings

logger = logging.getLogger(__name__)

# Module-level singleton — set once during startup by create_session_service()
_session_service: DatabaseSessionService | None = None


def create_session_service() -> DatabaseSessionService:
    """
    Create the ADK DatabaseSessionService for Cloud SQL (PostgreSQL).

    MUST be called after db_init.init_database() completes successfully.
    Tables must already exist before this is called.

    Returns:
        A configured DatabaseSessionService instance.
    """
    global _session_service

    # ADK uses SQLAlchemy sync engine internally — use psycopg2 driver.
    # asyncpg is used by OUR async engine (db_init.py) but NOT here.
    sync_url = settings.DATABASE_URL.replace(
        "postgresql+asyncpg://", "postgresql+psycopg2://"
    )

    logger.info("Creating ADK DatabaseSessionService (psycopg2 sync driver)...")

    _session_service = DatabaseSessionService(
        db_url=sync_url,
        # Additional SQLAlchemy engine kwargs
        pool_size=settings.DB_POOL_SIZE,
        max_overflow=settings.DB_MAX_OVERFLOW,
        pool_pre_ping=True,
        pool_recycle=1800,
    )

    logger.info("✅ DatabaseSessionService ready.")
    return _session_service


def get_session_service() -> DatabaseSessionService:
    """
    Get the shared session service instance.
    Raises if create_session_service() hasn't been called yet.
    """
    if _session_service is None:
        raise RuntimeError(
            "Session service not initialized. "
            "Call create_session_service() after db_init.init_database()."
        )
    return _session_service
