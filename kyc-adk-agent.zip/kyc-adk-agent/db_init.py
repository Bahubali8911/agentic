"""
Database Initializer
====================
Ensures ALL required tables exist in Cloud SQL (PostgreSQL) BEFORE the
ADK pipeline starts. This is the first thing called on container startup.

Run order (enforced in main.py):
  1. db_init.init_database()   ← tables created / verified
  2. kyc pipeline starts       ← safe to use DatabaseSessionService

Why this matters on GKE:
  - Pods can start concurrently; CREATE TABLE IF NOT EXISTS is idempotent
  - If Cloud SQL proxy sidecar isn't ready yet we retry with backoff
  - Schema migrations (ADK v1.22.0+) are handled here too

ADK tables created automatically by DatabaseSessionService:
  - sessions        (session metadata: id, app_name, user_id, state, timestamps)
  - events          (full event history per session)

Our custom tables (KYC audit trail, job queue):
  - kyc_audit_jobs  (tracks pipeline execution per client_id)
  - kyc_audit_log   (immutable audit trail for compliance)
"""

import asyncio
import logging
from datetime import datetime, timezone

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import create_async_engine, AsyncEngine
from sqlalchemy import text

from config.settings import settings

logger = logging.getLogger(__name__)

# ─── Custom Table Definitions ────────────────────────────────────────────────

metadata = sa.MetaData()

# Tracks one row per KYC audit job — used for resume-on-restart logic
kyc_audit_jobs = sa.Table(
    "kyc_audit_jobs",
    metadata,
    sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
    sa.Column("client_id", sa.String(255), nullable=False, index=True),
    sa.Column("session_id", sa.String(255), nullable=False, unique=True),
    sa.Column(
        "status",
        sa.String(50),
        nullable=False,
        default="PENDING",
        comment="PENDING | FETCH_COMPLETE | CLASSIFY_COMPLETE | MATCH_COMPLETE | DONE | FAILED",
    ),
    sa.Column("kyc_overall_status", sa.String(20), nullable=True, comment="PASS | FAIL"),
    sa.Column("total_documents", sa.Integer, nullable=True),
    sa.Column("gcs_report_uri", sa.String(1024), nullable=True),
    sa.Column("error_message", sa.Text, nullable=True),
    sa.Column("retry_count", sa.Integer, nullable=False, default=0),
    sa.Column(
        "created_at",
        sa.DateTime,
        nullable=False,
        default=lambda: datetime.now(timezone.utc).replace(tzinfo=None),
    ),
    sa.Column(
        "updated_at",
        sa.DateTime,
        nullable=False,
        default=lambda: datetime.now(timezone.utc).replace(tzinfo=None),
        onupdate=lambda: datetime.now(timezone.utc).replace(tzinfo=None),
    ),
)

# Immutable compliance audit trail — append-only, never updated
kyc_audit_log = sa.Table(
    "kyc_audit_log",
    metadata,
    sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
    sa.Column("client_id", sa.String(255), nullable=False, index=True),
    sa.Column("session_id", sa.String(255), nullable=False, index=True),
    sa.Column(
        "event_type",
        sa.String(100),
        nullable=False,
        comment="FETCH_STARTED | FETCH_COMPLETE | CLASSIFY_COMPLETE | MATCH_COMPLETE | STORED | FAILED",
    ),
    sa.Column("agent_name", sa.String(100), nullable=True),
    sa.Column("details", sa.JSON, nullable=True),
    sa.Column(
        "logged_at",
        sa.DateTime,
        nullable=False,
        default=lambda: datetime.now(timezone.utc).replace(tzinfo=None),
    ),
)


# ─── Core Init Function ───────────────────────────────────────────────────────

async def init_database(
    max_retries: int = 10,
    retry_delay_seconds: float = 3.0,
) -> AsyncEngine:
    """
    Connect to PostgreSQL and ensure all tables exist.

    Retries with backoff to handle Cloud SQL Auth Proxy sidecar startup lag.
    Called once at container startup BEFORE the ADK pipeline runs.

    Args:
        max_retries: How many connection attempts before giving up.
        retry_delay_seconds: Seconds to wait between retries.

    Returns:
        The connected AsyncEngine (can be reused by the app).

    Raises:
        RuntimeError: If the database is unreachable after all retries.
    """
    logger.info("=== Database Initialization Starting ===")
    logger.info(f"Target: {_redacted_url(settings.DATABASE_URL)}")

    engine = None

    for attempt in range(1, max_retries + 1):
        try:
            logger.info(f"Connection attempt {attempt}/{max_retries}...")

            engine = create_async_engine(
                settings.DATABASE_URL,
                echo=settings.DB_ECHO_SQL,
                pool_size=settings.DB_POOL_SIZE,
                max_overflow=settings.DB_MAX_OVERFLOW,
                pool_pre_ping=True,          # validates connection before use
                pool_recycle=1800,           # recycle connections every 30 min
                connect_args={
                    # asyncpg-specific: statement timeout 30s
                    "command_timeout": 30,
                    # NOTE: avoid asyncpg + timezone-aware datetime bug
                    # ADK issue #4366 — strip tzinfo before writing timestamps
                    "server_settings": {"timezone": "UTC"},
                },
            )

            # Test the connection
            async with engine.connect() as conn:
                await conn.execute(text("SELECT 1"))

            logger.info("✅ Database connection established.")
            break

        except Exception as e:
            logger.warning(f"Attempt {attempt} failed: {e}")
            if engine:
                await engine.dispose()
                engine = None
            if attempt == max_retries:
                raise RuntimeError(
                    f"Cannot connect to database after {max_retries} attempts. "
                    f"Last error: {e}"
                )
            await asyncio.sleep(retry_delay_seconds)

    # ── Create ADK tables (sessions + events) ────────────────────────────────
    # DatabaseSessionService calls create_all internally when first instantiated,
    # but we do it here explicitly so it happens before the service is created,
    # and we can log it for visibility.
    logger.info("Creating ADK session tables (idempotent)...")
    await _create_adk_tables(engine)

    # ── Create our custom KYC tables ─────────────────────────────────────────
    logger.info("Creating KYC custom tables (idempotent)...")
    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all, checkfirst=True)

    # ── Verify all expected tables exist ─────────────────────────────────────
    await _verify_tables(engine)

    logger.info("=== Database Initialization Complete ===")
    return engine


async def _create_adk_tables(engine: AsyncEngine) -> None:
    """
    Explicitly create the ADK-managed tables by instantiating
    DatabaseSessionService. ADK calls SQLAlchemy create_all internally.

    We do this here (before pipeline start) so any schema issues surface
    at startup time, not mid-audit.
    """
    from google.adk.sessions import DatabaseSessionService

    # ADK uses a sync SQLAlchemy engine internally (issue #1005 — still open).
    # It accepts the plain postgresql+psycopg2 URL for its own setup.
    sync_url = settings.DATABASE_URL.replace(
        "postgresql+asyncpg://", "postgresql+psycopg2://"
    )
    service = DatabaseSessionService(db_url=sync_url)
    # Instantiation triggers create_all on the ADK schema
    logger.info("ADK DatabaseSessionService instantiated — tables created.")
    return service


async def _verify_tables(engine: AsyncEngine) -> None:
    """
    Confirm all expected tables exist. Raises if any are missing.
    Gives a clear error message rather than a cryptic SQLAlchemy error later.
    """
    expected_tables = [
        # ADK-managed
        "sessions",
        "events",
        # Our custom tables
        "kyc_audit_jobs",
        "kyc_audit_log",
    ]

    async with engine.connect() as conn:
        result = await conn.execute(
            text(
                "SELECT tablename FROM pg_tables "
                "WHERE schemaname = 'public'"
            )
        )
        existing = {row[0] for row in result.fetchall()}

    missing = [t for t in expected_tables if t not in existing]
    if missing:
        raise RuntimeError(
            f"Table verification failed. Missing tables: {missing}. "
            "Check database permissions and ADK version."
        )

    logger.info(f"✅ All tables verified: {expected_tables}")


def _redacted_url(url: str) -> str:
    """Redact password from DB URL for safe logging."""
    try:
        from urllib.parse import urlparse, urlunparse
        parsed = urlparse(url)
        redacted = parsed._replace(
            netloc=f"{parsed.username}:***@{parsed.hostname}:{parsed.port}"
        )
        return urlunparse(redacted)
    except Exception:
        return "<db_url>"
