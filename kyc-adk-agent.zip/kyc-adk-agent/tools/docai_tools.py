"""
Tools for Agent 2: Document Classifier
Wraps the custom DocAI classification API.
"""

import httpx
from config.settings import settings


def classify_document(content_base64: str, filename: str) -> dict:
    """
    Classify a PDF document using the custom DocAI wrapper API.

    Args:
        content_base64: Base64-encoded PDF content.
        filename: Original filename, used as metadata hint.

    Returns:
        A dict containing:
          - success (bool)
          - document_type (str): e.g. "PASSPORT", "PROOF_OF_ADDRESS", "BANK_STATEMENT"
          - confidence (float): 0.0 to 1.0
          - raw_response (dict): Full API response for audit trail
          - error (str, optional)
    """
    try:
        response = httpx.post(
            f"{settings.DOCAI_API_BASE_URL}/classify",
            json={
                "content": content_base64,
                "filename": filename,
                "mime_type": "application/pdf",
            },
            headers={
                "Authorization": f"Bearer {settings.DOCAI_API_KEY}",
                "Content-Type": "application/json",
            },
            timeout=120,  # DocAI processing can be slow
        )
        response.raise_for_status()
        data = response.json()

        return {
            "success": True,
            "document_type": data.get("document_type", "UNKNOWN"),
            "confidence": float(data.get("confidence", 0.0)),
            "raw_response": data,
        }
    except httpx.HTTPStatusError as e:
        return {
            "success": False,
            "document_type": "UNKNOWN",
            "confidence": 0.0,
            "raw_response": {},
            "error": str(e),
        }
    except Exception as e:
        return {
            "success": False,
            "document_type": "UNKNOWN",
            "confidence": 0.0,
            "raw_response": {},
            "error": str(e),
        }
