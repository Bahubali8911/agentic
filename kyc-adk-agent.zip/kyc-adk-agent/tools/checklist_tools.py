"""
Tools for Agent 3: Checklist Matcher
Loads KYC checklists and generates the structured audit report.
"""

import json
from datetime import datetime, timezone
from config.settings import settings
from config.kyc_checklist import KYC_CHECKLISTS


def load_kyc_checklist(client_id: str) -> dict:
    """
    Load the KYC document checklist for a given client.

    The checklist defines which document types are required for this client's profile.
    In a production system this could be fetched from a rules engine or database.

    Args:
        client_id: The client identifier (used to determine client type/profile).

    Returns:
        A dict containing:
          - client_id (str)
          - client_type (str): e.g. "INDIVIDUAL", "CORPORATE"
          - required_documents (list): Each item:
              { required_document_type, is_mandatory, description, max_allowed }
    """
    # In production: fetch from your rules engine / config service
    # Here we use a config-driven approach with client type lookup
    client_type = _lookup_client_type(client_id)
    checklist = KYC_CHECKLISTS.get(client_type, KYC_CHECKLISTS["INDIVIDUAL"])

    return {
        "client_id": client_id,
        "client_type": client_type,
        "required_documents": checklist,
    }


def generate_audit_report(client_id: str, audit_result: dict) -> dict:
    """
    Generate a structured KYC audit report from the matching results.

    Args:
        client_id: The client identifier.
        audit_result: Dict containing:
          - checklist_matches: list of per-requirement results
          - unexpected_documents: list of docs not on checklist
          - overall_status: "PASS" or "FAIL"

    Returns:
        A dict containing the full report, ready to be serialised to JSON.
    """
    now = datetime.now(timezone.utc)

    report = {
        "report_id": f"KYC-{client_id}-{now.strftime('%Y%m%d%H%M%S')}",
        "client_id": client_id,
        "audit_timestamp": now.isoformat(),
        "overall_kyc_status": audit_result.get("overall_status", "FAIL"),
        "summary": {
            "total_documents_received": audit_result.get("total_documents", 0),
            "matched": sum(
                1 for r in audit_result.get("checklist_matches", [])
                if r.get("status") == "PRESENT"
            ),
            "missing_mandatory": sum(
                1 for r in audit_result.get("checklist_matches", [])
                if r.get("status") == "MISSING" and r.get("is_mandatory")
            ),
            "low_confidence": sum(
                1 for r in audit_result.get("checklist_matches", [])
                if r.get("status") == "LOW_CONFIDENCE"
            ),
            "duplicates": sum(
                1 for r in audit_result.get("checklist_matches", [])
                if r.get("status") == "DUPLICATE"
            ),
            "unexpected": len(audit_result.get("unexpected_documents", [])),
        },
        "checklist_results": audit_result.get("checklist_matches", []),
        "unexpected_documents": audit_result.get("unexpected_documents", []),
        "requires_human_review": audit_result.get("overall_status") != "PASS" or
            any(r.get("status") == "LOW_CONFIDENCE"
                for r in audit_result.get("checklist_matches", [])),
    }

    return {"success": True, "report": report, "report_json": json.dumps(report, indent=2)}


def _lookup_client_type(client_id: str) -> str:
    """
    Determine client type from client_id prefix or external lookup.
    Extend this to call your CRM or client database.
    """
    # Simple prefix-based logic for now; replace with real lookup
    if client_id.upper().startswith("CORP"):
        return "CORPORATE"
    return "INDIVIDUAL"
