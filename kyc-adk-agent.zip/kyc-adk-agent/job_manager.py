"""
KYC Job Manager
===============
Manages KYC audit jobs in the `kyc_audit_jobs` table.

Responsibilities:
  - Create a new job record when an audit starts
  - Update job status as each agent completes its step
  - Detect and resume in-progress jobs after a pod restart
  - Log all events to the `kyc_audit_log` compliance table

This is what makes the pipeline crash-safe on GKE:
  If pod A dies mid-audit, pod B reads the job table, finds status ≠ DONE,
  loads the existing session_id from DatabaseSessionService, and continues
  from the last completed checkpoint.
"""

import logging
from datetime import datetime, timezone
from typing import Optional

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncEngine

from db_init import kyc_audit_jobs, kyc_audit_log

logger = logging.getLogger(__name__)

# Maps each agent to its completion status (in pipeline order)
PIPELINE_STAGES = [
    "PENDING",
    "FETCH_COMPLETE",
    "CLASSIFY_COMPLETE",
    "MATCH_COMPLETE",
    "DONE",
]


class KycJobManager:
    """
    CRUD interface for the kyc_audit_jobs and kyc_audit_log tables.
    Uses the async SQLAlchemy engine directly (not ADK session service).
    """

    def __init__(self, engine: AsyncEngine):
        self.engine = engine

    # ── Job Lifecycle ─────────────────────────────────────────────────────────

    async def create_job(self, client_id: str, session_id: str) -> int:
        """
        Insert a new audit job row. Returns the new job id.
        Called at the very start of a fresh audit run.
        """
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        async with self.engine.begin() as conn:
            result = await conn.execute(
                kyc_audit_jobs.insert().values(
                    client_id=client_id,
                    session_id=session_id,
                    status="PENDING",
                    retry_count=0,
                    created_at=now,
                    updated_at=now,
                )
            )
        job_id = result.inserted_primary_key[0]
        logger.info(f"Created job {job_id} for client {client_id} | session {session_id}")
        return job_id

    async def update_status(
        self,
        session_id: str,
        status: str,
        *,
        kyc_overall_status: Optional[str] = None,
        total_documents: Optional[int] = None,
        gcs_report_uri: Optional[str] = None,
        error_message: Optional[str] = None,
    ) -> None:
        """
        Update the job status after an agent completes (or fails).
        Called by each agent's output callback.
        """
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        values = {"status": status, "updated_at": now}
        if kyc_overall_status is not None:
            values["kyc_overall_status"] = kyc_overall_status
        if total_documents is not None:
            values["total_documents"] = total_documents
        if gcs_report_uri is not None:
            values["gcs_report_uri"] = gcs_report_uri
        if error_message is not None:
            values["error_message"] = error_message

        async with self.engine.begin() as conn:
            await conn.execute(
                kyc_audit_jobs.update()
                .where(kyc_audit_jobs.c.session_id == session_id)
                .values(**values)
            )
        logger.info(f"Job [{session_id}] → status: {status}")

    async def increment_retry(self, session_id: str) -> int:
        """Increment retry_count and return new value."""
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        async with self.engine.begin() as conn:
            result = await conn.execute(
                kyc_audit_jobs.update()
                .where(kyc_audit_jobs.c.session_id == session_id)
                .values(
                    retry_count=kyc_audit_jobs.c.retry_count + 1,
                    updated_at=now,
                )
                .returning(kyc_audit_jobs.c.retry_count)
            )
            row = result.fetchone()
        return row[0] if row else 0

    # ── Resume Logic ──────────────────────────────────────────────────────────

    async def find_incomplete_job(self, client_id: str) -> Optional[dict]:
        """
        Check if there is an unfinished audit for this client.
        Returns the job row dict if found, else None.

        Used on startup / retry to decide: start fresh or resume?
        """
        async with self.engine.connect() as conn:
            result = await conn.execute(
                sa.select(kyc_audit_jobs)
                .where(
                    sa.and_(
                        kyc_audit_jobs.c.client_id == client_id,
                        kyc_audit_jobs.c.status.notin_(["DONE", "FAILED"]),
                    )
                )
                .order_by(kyc_audit_jobs.c.created_at.desc())
                .limit(1)
            )
            row = result.mappings().fetchone()
        return dict(row) if row else None

    async def get_job_by_session(self, session_id: str) -> Optional[dict]:
        """Fetch job row by session_id."""
        async with self.engine.connect() as conn:
            result = await conn.execute(
                sa.select(kyc_audit_jobs).where(
                    kyc_audit_jobs.c.session_id == session_id
                )
            )
            row = result.mappings().fetchone()
        return dict(row) if row else None

    # ── Audit Log (append-only compliance trail) ──────────────────────────────

    async def log_event(
        self,
        client_id: str,
        session_id: str,
        event_type: str,
        agent_name: Optional[str] = None,
        details: Optional[dict] = None,
    ) -> None:
        """
        Append an immutable audit log entry.
        Never updated — only inserted. Used for compliance reporting.
        """
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        async with self.engine.begin() as conn:
            await conn.execute(
                kyc_audit_log.insert().values(
                    client_id=client_id,
                    session_id=session_id,
                    event_type=event_type,
                    agent_name=agent_name,
                    details=details or {},
                    logged_at=now,
                )
            )
        logger.debug(f"Audit log: [{client_id}] {event_type} | {agent_name}")
