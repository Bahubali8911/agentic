"""
Agent 1: Document Fetcher
Responsibility:
  - Search for documents using client_id via REST API → get tokens
  - Download each document one-by-one using the token
  - Store raw PDFs temporarily in session state for downstream agents
"""

from google.adk.agents import LlmAgent
from tools.document_api_tools import search_documents, download_document


document_fetcher_agent = LlmAgent(
    name="DocumentFetcherAgent",
    model="gemini-2.5-flash",
    description=(
        "Fetches all KYC documents for a given client. "
        "First calls the search API to retrieve document tokens, "
        "then downloads each document individually."
    ),
    instruction="""
You are the Document Fetcher agent in a KYC audit pipeline.

Your job:
1. Call `search_documents` with the `client_id` from session state.
   - This returns a list of document metadata objects, each containing a `token`.
2. For each document token returned, call `download_document(token)` to retrieve the PDF bytes.
3. Store all downloaded documents in session state as `fetched_documents`.
   - Each entry should include: { token, filename, content_base64, metadata }
4. Report the total number of documents fetched.

Important:
- Download ALL documents — do not skip any.
- If a download fails for a specific token, log the failure and continue with the rest.
- Set session state key `fetch_complete = true` when done.
""",
    tools=[search_documents, download_document],
)
