"""
KYC Auditor - Root Coordinator Agent
Orchestrates the full KYC document audit pipeline using Google ADK.
"""

from google.adk.agents import SequentialAgent, LlmAgent
from agents.document_fetcher import document_fetcher_agent
from agents.doc_classifier import doc_classifier_agent
from agents.checklist_matcher import checklist_matcher_agent
from agents.storage_agent import storage_agent

# ─── Root Pipeline ─────────────────────────────────────────────────────────────
# Uses SequentialAgent to guarantee strict execution order:
#   1. Fetch → 2. Classify → 3. Match → 4. Store

kyc_pipeline = SequentialAgent(
    name="KYCAuditorPipeline",
    description=(
        "End-to-end KYC document audit pipeline. "
        "Fetches client documents, classifies them via DocAI, "
        "matches against the KYC checklist, and stores results in GCS."
    ),
    sub_agents=[
        document_fetcher_agent,
        doc_classifier_agent,
        checklist_matcher_agent,
        storage_agent,
    ],
)
