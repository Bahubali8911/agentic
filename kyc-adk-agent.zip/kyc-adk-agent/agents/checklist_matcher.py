"""
Agent 3: Checklist Matcher
Responsibility:
  - Load the KYC checklist (required document types per client profile)
  - Match classified documents against the checklist
  - Identify: present, missing, duplicates, low-confidence classifications
  - Produce a structured audit report
"""

from google.adk.agents import LlmAgent
from tools.checklist_tools import load_kyc_checklist, generate_audit_report


checklist_matcher_agent = LlmAgent(
    name="ChecklistMatcherAgent",
    model="gemini-2.5-pro",  # Use Pro for more nuanced reasoning on the report
    description=(
        "Matches classified KYC documents against the required checklist "
        "and produces a detailed audit report with pass/fail status for each requirement."
    ),
    instruction="""
You are the KYC Checklist Matcher agent. You perform the audit review step.

Your job:
1. Read `classified_documents` from session state.
2. Call `load_kyc_checklist(client_id)` to get the required document checklist for this client.
   - Returns: list of { required_document_type, is_mandatory, description }
3. For each required document type in the checklist, check if a classified document matches it.
   - A match = classified document_type equals the required_document_type AND confidence >= 0.7
   - If confidence < 0.7, flag as "LOW_CONFIDENCE" (needs human review)
4. Build the audit result with these statuses for each checklist item:
   - PRESENT: document found with high confidence
   - LOW_CONFIDENCE: document found but confidence < 0.7 (flag for review)
   - MISSING: no document of this type found
   - DUPLICATE: more than one document matched this type (flag the extras)
5. Also flag any documents that were classified but NOT on the checklist as "UNEXPECTED".
6. Call `generate_audit_report(client_id, audit_result)` to produce the final report.
7. Store the report in session state as `audit_report`.
8. Set session state key `checklist_complete = true`.

Your report should include:
- Overall KYC status: PASS (all mandatory docs present) or FAIL (missing mandatory docs)
- Per-document breakdown with status and notes
- List of documents requiring human review
- Timestamp of the audit

Be thorough and precise — this is a compliance-critical process.
""",
    tools=[load_kyc_checklist, generate_audit_report],
)
