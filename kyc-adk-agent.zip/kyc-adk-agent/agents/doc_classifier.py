"""
Agent 2: Document Classifier
Responsibility:
  - Iterate over all fetched documents from session state
  - Send each PDF to the custom DocAI wrapper API one-by-one
  - Collect classification results (document type, confidence score)
  - Store classified documents in session state for the checklist agent
"""

from google.adk.agents import LlmAgent
from tools.docai_tools import classify_document


doc_classifier_agent = LlmAgent(
    name="DocClassifierAgent",
    model="gemini-2.5-flash",
    description=(
        "Classifies each fetched KYC document by calling the DocAI API. "
        "Determines document type (e.g. Passport, Proof of Address, Bank Statement) "
        "and confidence score for each."
    ),
    instruction="""
You are the Document Classifier agent in a KYC audit pipeline.

Your job:
1. Read `fetched_documents` from session state (set by DocumentFetcherAgent).
2. For each document, call `classify_document(content_base64, filename)`.
   - This returns: { document_type, confidence, raw_response }
3. Attach the classification result to each document entry.
4. Store the enriched list in session state as `classified_documents`.
   - Each entry: { token, filename, content_base64, metadata, document_type, confidence }
5. Log a summary: how many classified successfully, any failures.

Important:
- Process documents one at a time (DocAI API does not support batching).
- If classification fails for a document, set document_type = "UNKNOWN" and confidence = 0.
- Do NOT skip documents — every fetched document must have a classification result.
- Set session state key `classification_complete = true` when done.
""",
    tools=[classify_document],
)
