"""
Agent 4: Storage Agent
Responsibility:
  - Rename each classified document using a standardized naming convention
  - Upload renamed documents to GCS
  - Upload the audit report to GCS
  - Return GCS paths for all stored files
"""

from google.adk.agents import LlmAgent
from tools.gcs_tools import upload_to_gcs, generate_document_name


storage_agent = LlmAgent(
    name="StorageAgent",
    model="gemini-2.5-flash",
    description=(
        "Renames KYC documents using a standardized convention and uploads them "
        "to Google Cloud Storage, along with the final audit report."
    ),
    instruction="""
You are the Storage Agent in a KYC audit pipeline. Your job is to persist all outputs to GCS.

Your job:
1. Read `classified_documents` and `audit_report` from session state.
2. Read `client_id` from session state.
3. For each classified document:
   a. Call `generate_document_name(client_id, document_type, original_filename, index)`
      to get a standardized filename.
      Convention: {client_id}_{document_type}_{YYYYMMDD}_{index}.pdf
      Example: CLI123_PASSPORT_20250226_001.pdf
   b. Call `upload_to_gcs(content_base64, destination_filename, folder=client_id)`
      to upload the renamed document to GCS.
   c. Record the GCS URI returned.
4. Upload the audit report JSON:
   - Filename: {client_id}_KYC_AUDIT_REPORT_{YYYYMMDD}.json
   - Call `upload_to_gcs(report_json, report_filename, folder=client_id)`
5. Store all GCS URIs in session state as `stored_files`:
   - { filename, original_filename, document_type, gcs_uri }
6. Set session state key `storage_complete = true`.
7. Summarize: total files uploaded, GCS bucket/folder path.

Important:
- If a document has document_type = "UNKNOWN", still upload it with the UNKNOWN label.
- Never skip documents — all fetched documents must be stored.
- The GCS folder structure is: gs://{bucket}/{client_id}/
""",
    tools=[generate_document_name, upload_to_gcs],
)
